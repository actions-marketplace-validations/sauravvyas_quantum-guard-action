"""
QuantumGuard CLI — Typer-based command interface.

Commands:
  quantumguard scan      — Scan for legacy cryptography
  quantumguard remediate — Remediate findings
  quantumguard cbom      — Generate CycloneDX CBOM
  quantumguard plugins   — List registered plugins
  quantumguard doctor    — System health check
  quantumguard version   — Show version
"""
from __future__ import annotations

import json
import logging
import sys
from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

app = typer.Typer(
    name="quantumguard",
    help="🔐 QuantumGuard — Privacy-first Post-Quantum Cryptography migration platform",
    rich_markup_mode="markdown",
    add_completion=True,
    no_args_is_help=True,
)

remediate_app = typer.Typer(help="Remediate cryptographic findings")
app.add_typer(remediate_app, name="remediate")

console = Console()
err_console = Console(stderr=True)


def _bootstrap() -> None:
    """Bootstrap plugins and configure logging."""
    from quantumguard.plugins import bootstrap
    from quantumguard.core.config import get_config

    config = get_config()
    logging.basicConfig(
        level=getattr(logging, config.log_level, logging.INFO),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    bootstrap()


def _detect_git_branch(path: Path) -> str | None:
    """Best-effort current branch name for a (possibly non-git) target path."""
    try:
        import git as gitpython
        repo = gitpython.Repo(path, search_parent_directories=True)
        return repo.active_branch.name
    except Exception:
        return None


# ---------------------------------------------------------------------------
# scan
# ---------------------------------------------------------------------------


@app.command("scan")
def cmd_scan(
    target: Annotated[
        Path,
        typer.Argument(help="Directory or file to scan", exists=True, resolve_path=True),
    ] = Path("."),
    language: Annotated[
        Optional[str],
        typer.Option("--language", "-l", help="Force language detection (python|java|node|go|dotnet)"),
    ] = None,
    output: Annotated[
        Optional[Path],
        typer.Option("--output", "-o", help="Save JSON report to file"),
    ] = None,
    cbom: Annotated[
        bool,
        typer.Option("--cbom", help="Also generate a CycloneDX CBOM"),
    ] = False,
    cbom_output: Annotated[
        Optional[Path],
        typer.Option("--cbom-output", help="CBOM output path (default: .quantumguard/cbom.json)"),
    ] = None,
    fail_on_findings: Annotated[
        bool,
        typer.Option("--fail-on-findings", help="Exit with code 1 if findings are detected"),
    ] = False,
    severity_threshold: Annotated[
        str,
        typer.Option("--min-severity", help="Minimum severity to report (CRITICAL|HIGH|MEDIUM|LOW|INFO)"),
    ] = "INFO",
) -> None:
    """
    🔍 **Scan** a directory or file for legacy cryptographic usage.

    Source code is processed locally — never transmitted.
    """
    _bootstrap()

    from quantumguard.core.orchestrator import Orchestrator
    from quantumguard.core.models import ScanTarget, SupportedAdapter
    from quantumguard.core.reporter import Reporter
    from quantumguard.core.config import get_config
    from quantumguard.cbom.generator import CBOMGenerator

    reporter = Reporter(console=console)
    reporter.print_banner()

    config = get_config()
    orchestrator = Orchestrator(config=config)

    scan_target = ScanTarget(
        path=target,
        adapter=SupportedAdapter.FILESYSTEM,
    )

    with console.status("[bold blue]Scanning for legacy cryptography...[/bold blue]"):
        try:
            result = orchestrator.scan(scan_target, language_override=language)
        except Exception as exc:
            err_console.print(f"[red]Scan failed: {exc}[/red]")
            raise typer.Exit(code=2)

    reporter.print_scan_summary(result)

    from quantumguard.core.scan_reporting import report_scan
    report_scan(result, provider="filesystem", repo=str(target), local_only=True)

    # Save JSON report
    if output:
        report = {
            "scan_id": result.id,
            "target": str(result.target.path),
            "files_scanned": result.files_scanned,
            "total_findings": result.total_findings,
            "findings": [
                {
                    "id": f.id,
                    "file": str(f.file),
                    "line": f.line,
                    "column": f.column,
                    "algorithm": str(f.algorithm),
                    "library": f.library,
                    "severity": str(f.severity),
                    "rule_id": f.rule_id,
                    "recommendation": f.recommendation,
                }
                for f in result.findings
            ],
        }
        output.write_text(json.dumps(report, indent=2), encoding="utf-8")
        console.print(f"\n[green]✅ Report saved to: {output}[/green]")

    # Generate CBOM
    if cbom:
        cbom_path = cbom_output or (config.output_dir / "cbom.json")
        gen = CBOMGenerator()
        gen.save(result, cbom_path)
        console.print(f"[green]✅ CBOM saved to: {cbom_path}[/green]")

    if fail_on_findings and result.findings:
        raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# remediate filesystem
# ---------------------------------------------------------------------------


@remediate_app.command("local")
def cmd_remediate_local(
    target: Annotated[
        Path,
        typer.Argument(help="Directory or file to remediate", exists=True, resolve_path=True),
    ] = Path("."),
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Show what would be changed without modifying files"),
    ] = False,
    language: Annotated[
        Optional[str],
        typer.Option("--language", "-l"),
    ] = None,
) -> None:
    """🔧 **Remediate** cryptographic findings in a local directory."""
    _bootstrap()

    from quantumguard.core.orchestrator import Orchestrator
    from quantumguard.core.models import ScanTarget, RemediationPlan, SupportedAdapter
    from quantumguard.core.reporter import Reporter
    from quantumguard.core.config import get_config

    reporter = Reporter(console=console)
    reporter.print_banner()
    config = get_config()
    orchestrator = Orchestrator(config=config)

    scan_target = ScanTarget(path=target, adapter=SupportedAdapter.FILESYSTEM)

    with console.status("[bold blue]Scanning...[/bold blue]"):
        scan_result = orchestrator.scan(scan_target, language_override=language)

    reporter.print_scan_summary(scan_result)

    from quantumguard.core.scan_reporting import report_scan
    report_scan(
        scan_result,
        provider="filesystem",
        repo=str(target),
        branch=_detect_git_branch(target),
        local_only=False,
    )

    if not scan_result.findings:
        console.print("[green]✅ Nothing to remediate![/green]")
        return

    if not dry_run:
        confirm = typer.confirm(
            f"\nRemediate {scan_result.total_findings} finding(s)?", default=True
        )
        if not confirm:
            raise typer.Abort()

    plan = RemediationPlan(
        scan_result_id=scan_result.id,
        findings=scan_result.findings,
        dry_run=dry_run,
    )

    with console.status("[bold green]Applying remediations...[/bold green]"):
        result = orchestrator.remediate(plan, adapter_key="filesystem")

    reporter.print_remediation_result(result)


# ---------------------------------------------------------------------------
# remediate github
# ---------------------------------------------------------------------------


@remediate_app.command("github")
def cmd_remediate_github(
    repo: Annotated[str, typer.Argument(help="Repository in org/name format")],
    base_branch: Annotated[str, typer.Option("--base-branch", help="Base branch")] = "main",
    target_branch: Annotated[
        Optional[str],
        typer.Option("--branch", help="Branch to create (default: auto-generated)"),
    ] = None,
    create_pr: Annotated[
        bool, typer.Option("--create-pr", help="Create a Pull Request after remediation")
    ] = False,
    dry_run: Annotated[bool, typer.Option("--dry-run")] = False,
) -> None:
    """
    🐙 **Remediate** a GitHub repository and optionally create a Pull Request.

    Example:
        quantumguard remediate github org/myrepo --create-pr
    """
    _bootstrap()

    from quantumguard.adapters.github import GitHubAdapter
    from quantumguard.core.config import get_config
    from quantumguard.core.reporter import Reporter

    reporter = Reporter(console=console)
    reporter.print_banner()

    config = get_config()

    with GitHubAdapter(config=config) as adapter:
        with console.status(f"[bold blue]Processing {repo}...[/bold blue]"):
            try:
                result = adapter.full_remediation_pipeline(
                    repo=repo,
                    base_branch=base_branch,
                    target_branch=target_branch,
                    create_pr=create_pr,
                    dry_run=dry_run,
                )
            except Exception as exc:
                err_console.print(f"[red]Pipeline failed: {exc}[/red]")
                raise typer.Exit(code=2)

    scan_result = result["scan"]
    remediation = result["remediation"]
    pr_url = result["pr_url"]

    from quantumguard.core.scan_reporting import report_scan
    report_scan(
        scan_result, provider="github", repo=repo, branch=target_branch or base_branch,
        pr_url=pr_url, local_only=False,
    )

    reporter.print_scan_summary(scan_result)
    if remediation:
        reporter.print_remediation_result(remediation)
    if pr_url:
        console.print(f"\n[green]✅ Pull Request: {pr_url}[/green]")


# ---------------------------------------------------------------------------
# cbom
# ---------------------------------------------------------------------------


@app.command("cbom")
def cmd_cbom(
    target: Annotated[Path, typer.Argument(exists=True, resolve_path=True)] = Path("."),
    output: Annotated[
        Optional[Path],
        typer.Option("--output", "-o", help="Output path for CBOM JSON"),
    ] = None,
    language: Annotated[Optional[str], typer.Option("--language", "-l")] = None,
    pretty: Annotated[bool, typer.Option("--pretty/--compact")] = True,
) -> None:
    """
    📋 **Generate** a CycloneDX 1.6 Cryptographic Bill of Materials (CBOM).
    """
    _bootstrap()

    from quantumguard.core.orchestrator import Orchestrator
    from quantumguard.core.models import ScanTarget, SupportedAdapter
    from quantumguard.core.config import get_config
    from quantumguard.cbom.generator import CBOMGenerator

    config = get_config()
    orchestrator = Orchestrator(config=config)
    scan_target = ScanTarget(path=target, adapter=SupportedAdapter.FILESYSTEM)

    with console.status("[bold blue]Scanning for CBOM generation...[/bold blue]"):
        scan_result = orchestrator.scan(scan_target, language_override=language)

    gen = CBOMGenerator()
    cbom_data = gen.generate(scan_result)
    cbom_json = json.dumps(cbom_data, indent=2 if pretty else None, default=str)

    out_path = output or (config.output_dir / "cbom.json")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(cbom_json, encoding="utf-8")

    console.print(f"[green]✅ CBOM generated: {out_path}[/green]")
    console.print(f"   Components: {len(cbom_data.get('components', []))}")
    console.print(f"   Crypto Assets: {len(cbom_data.get('cryptographyAssets', []))}")
    console.print(f"   Vulnerabilities: {len(cbom_data.get('vulnerabilities', []))}")


# ---------------------------------------------------------------------------
# plugins
# ---------------------------------------------------------------------------


@app.command("plugins")
def cmd_plugins() -> None:
    """🔌 **List** all registered plugins (engines, adapters, remediators)."""
    _bootstrap()

    from quantumguard.core.registry import (
        get_registered_engines,
        get_registered_adapters,
        get_registered_remediators,
    )

    table = Table(title="Registered Plugins", show_header=True)
    table.add_column("Type", style="bold cyan")
    table.add_column("Name", style="bold")
    table.add_column("Status")

    for engine in get_registered_engines():
        table.add_row("Engine", engine, "[green]✅ active[/green]")
    for adapter in get_registered_adapters():
        table.add_row("Adapter", adapter, "[green]✅ active[/green]")
    for remediator in get_registered_remediators():
        table.add_row("Remediator", remediator, "[green]✅ active[/green]")

    console.print(table)


# ---------------------------------------------------------------------------
# doctor
# ---------------------------------------------------------------------------


@app.command("doctor")
def cmd_doctor() -> None:
    """🩺 **Check** system health and dependencies."""
    _bootstrap()

    import sys
    import importlib

    from quantumguard.core.reporter import Reporter
    from quantumguard.core.models import SystemHealth
    from quantumguard.core.registry import (
        get_registered_engines,
        get_registered_adapters,
        get_registered_remediators,
    )
    from quantumguard.core.constants import VERSION

    required_deps = [
        "typer", "rich", "libcst", "pydantic", "httpx",
        "git", "github", "gitlab", "toml", "yaml",
    ]

    dep_status = {}
    for dep in required_deps:
        try:
            importlib.import_module(dep)
            dep_status[dep] = True
        except ImportError:
            dep_status[dep] = False

    issues = [f"Missing dependency: {d}" for d, ok in dep_status.items() if not ok]

    health = SystemHealth(
        quantumguard_version=VERSION,
        python_version=sys.version,
        registered_engines=get_registered_engines(),
        registered_adapters=get_registered_adapters(),
        registered_remediators=get_registered_remediators(),
        dependencies=dep_status,
        issues=issues,
    )

    Reporter(console=console).print_health(health)


# ---------------------------------------------------------------------------
# version
# ---------------------------------------------------------------------------


@app.command("version")
def cmd_version() -> None:
    """ℹ️  **Show** QuantumGuard version information."""
    from quantumguard.core.constants import VERSION

    console.print(
        Panel(
            f"[bold blue]QuantumGuard[/bold blue] v[bold]{VERSION}[/bold]\n"
            "[dim]Privacy-first Post-Quantum Cryptography migration platform[/dim]\n"
            "[dim]https://quantumguard.io[/dim]",
            border_style="blue",
        )
    )


# ---------------------------------------------------------------------------
# auth
# ---------------------------------------------------------------------------


@app.command("auth")
def cmd_auth(
    license_key: Annotated[
        Optional[str],
        typer.Argument(help="Your QuantumGuard license key"),
    ] = None,
) -> None:
    """
    🔐 **Authenticate** the CLI with your license key.
    """
    from quantumguard.core.licensing import save_license_key, TRIAL_KEY, LICENSE_PATTERN

    if not license_key:
        license_key = typer.prompt("Enter your QuantumGuard license key")

    key_clean = license_key.strip()
    if key_clean == TRIAL_KEY or LICENSE_PATTERN.match(key_clean):
        if save_license_key(key_clean):
            console.print("[green]✅ Authentication successful! License key saved to ~/.quantumguard/license.key[/green]")
        else:
            err_console.print("[red]❌ Error: Could not save license key to ~/.quantumguard/license.key. Check file permissions.[/red]")
            raise typer.Exit(code=1)
    else:
        err_console.print("[red]❌ Error: Invalid license key format. Key should look like QG-XXXX-XXXX-XXXX[/red]")
        raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    app()


if __name__ == "__main__":
    main()
