"""
GitLab adapter — stub for plugin-based extension.
"""
from __future__ import annotations

import logging
from pathlib import Path

from quantumguard.adapters.git import GitAdapter
from quantumguard.core.config import QuantumGuardConfig
from quantumguard.core.exceptions import AuthenticationError, PullRequestError

logger = logging.getLogger(__name__)


class GitLabAdapter(GitAdapter):
    """GitLab source adapter with MR (Merge Request) support."""

    def __init__(self, config: QuantumGuardConfig) -> None:
        super().__init__(config)
        try:
            import gitlab as gitlab_lib
            token = config.gitlab_token
            if token is None:
                raise AuthenticationError("GitLab token not configured. Set QUANTUMGUARD_GITLAB_TOKEN.")
            self._gl = gitlab_lib.Gitlab(
                url=config.gitlab_url,
                private_token=token.get_secret_value(),
            )
            self._gl.auth()
        except ImportError:
            logger.warning("python-gitlab not installed. GitLab adapter limited.")
            self._gl = None

    def clone(self, repo_url: str, branch: str | None = None) -> Path:
        token = self.config.gitlab_token
        if token and "https://" in repo_url:
            authed_url = repo_url.replace(
                "https://",
                f"https://oauth2:{token.get_secret_value()}@",
            )
        else:
            authed_url = repo_url
        return super().clone(authed_url, branch=branch)

    def create_pull_request(
        self,
        repo: str,
        branch: str,
        title: str,
        body: str,
        base_branch: str = "main",
    ) -> str:
        if self._gl is None:
            raise PullRequestError("GitLab client not initialized")
        try:
            project = self._gl.projects.get(repo)
            mr = project.mergerequests.create(
                {
                    "source_branch": branch,
                    "target_branch": base_branch,
                    "title": title,
                    "description": body,
                }
            )
            return str(mr.web_url)
        except Exception as exc:
            raise PullRequestError(f"Failed to create GitLab MR: {exc}") from exc
