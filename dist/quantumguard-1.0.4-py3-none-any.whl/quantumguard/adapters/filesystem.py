"""
Local filesystem adapter.

Discovers and reads files from the local filesystem.
Source code never leaves the machine.
"""
from __future__ import annotations

import fnmatch
import logging
from pathlib import Path

from quantumguard.adapters.base import SourceAdapter
from quantumguard.core.models import ScanTarget

logger = logging.getLogger(__name__)


class LocalFileSystemAdapter(SourceAdapter):
    """
    Reads files directly from the local filesystem.

    This is the default adapter and the most privacy-preserving option —
    all operations are completely local.
    """

    def discover_files(self, target: ScanTarget) -> list[Path]:
        """Walk the target directory and return matching file paths."""
        root = Path(target.path).resolve()

        if not root.exists():
            logger.warning("Target path does not exist: %s", root)
            return []

        if root.is_file():
            return [root]

        discovered: list[Path] = []

        if target.recursive:
            all_files = list(root.rglob("*"))
        else:
            all_files = list(root.glob("*"))

        for file_path in all_files:
            if not file_path.is_file():
                continue

            # Check file size
            try:
                size = file_path.stat().st_size
                if size > target.max_file_size_bytes:
                    logger.debug("Skipping large file: %s (%d bytes)", file_path, size)
                    continue
            except OSError:
                continue

            rel = file_path.relative_to(root)
            rel_str = str(rel)

            # Apply exclude patterns
            if self._matches_any(rel_str, target.exclude_patterns):
                logger.debug("Excluded: %s", file_path)
                continue

            # Apply include patterns
            if not self._matches_any(rel_str, target.include_patterns):
                logger.debug("Not included: %s", file_path)
                continue

            discovered.append(file_path)

        logger.info("Discovered %d files in %s", len(discovered), root)
        return discovered

    def read_file(self, path: Path) -> str:
        """Read file content with encoding fallback."""
        for encoding in ("utf-8", "latin-1", "cp1252"):
            try:
                return path.read_text(encoding=encoding)
            except UnicodeDecodeError:
                continue
        logger.warning("Could not decode file: %s — skipping", path)
        return ""

    def write_file(self, path: Path, content: str) -> None:
        """Write content to file, creating parent directories as needed."""
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        logger.debug("Wrote file: %s", path)

    @staticmethod
    def _matches_any(path_str: str, patterns: list[str]) -> bool:
        """
        Check if path_str matches any of the given glob patterns.

        Supports both simple patterns (*.py) and ** patterns (**/venv/**).
        On POSIX, uses forward slashes for separator consistency.
        """
        normalized = path_str.replace("\\", "/")
        parts = normalized.split("/")

        for pattern in patterns:
            # Direct fnmatch check
            if fnmatch.fnmatch(normalized, pattern):
                return True

            # For ** patterns: check if any component or prefix matches
            pat_clean = pattern.replace("**/", "").replace("/**", "").strip("/")
            if pat_clean and any(
                fnmatch.fnmatch(part, pat_clean) for part in parts
            ):
                return True

            # Check each sub-path against the pattern
            for i in range(len(parts)):
                sub = "/".join(parts[i:])
                if fnmatch.fnmatch(sub, pattern.strip("*/")):
                    return True

        return False
