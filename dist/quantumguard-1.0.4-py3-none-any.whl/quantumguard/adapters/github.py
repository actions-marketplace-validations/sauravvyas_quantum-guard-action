"""
GitHub adapter — clone, scan, remediate, and create PRs on GitHub.
"""
from __future__ import annotations

import logging
from pathlib import Path

from github import Github, GithubException
from github.Repository import Repository

from quantumguard.adapters.git import GitAdapter
from quantumguard.core.config import QuantumGuardConfig
from quantumguard.core.constants import (
    DEFAULT_BRANCH_PREFIX,
    DEFAULT_PR_TITLE,
    DEFAULT_PR_BODY_TEMPLATE,
    VERSION,
)
from quantumguard.core.exceptions import (
    AuthenticationError,
    PullRequestError,
    RepositoryNotFoundError,
)

logger = logging.getLogger(__name__)


class GitHubAdapter(GitAdapter):
    """
    GitHub source adapter.

    Supports:
      - Cloning repositories (public & private via PAT)
      - Creating branches
      - Pushing changes
      - Creating pull requests via the GitHub REST API (PyGithub)
    """

    def __init__(self, config: QuantumGuardConfig) -> None:
        super().__init__(config)
        self._gh: Github | None = None
        self._gh_repo: Repository | None = None

    def _get_github_client(self) -> Github:
        if self._gh is None:
            token = self.config.github_token
            if token is None:
                raise AuthenticationError(
                    "GitHub token not configured. Set QUANTUMGUARD_GITHUB_TOKEN."
                )
            self._gh = Github(
                token.get_secret_value(),
                base_url=self.config.github_base_url,
            )
        return self._gh

    def clone(self, repo_url: str, branch: str | None = None) -> Path:
        """Clone a GitHub repo, injecting token authentication."""
        gh = self._get_github_client()
        token = self.config.github_token

        # Inject auth token into URL for private repos
        if token and "github.com" in repo_url and "https://" in repo_url:
            authed_url = repo_url.replace(
                "https://",
                f"https://oauth2:{token.get_secret_value()}@",
            )
        else:
            authed_url = repo_url

        return super().clone(authed_url, branch=branch)

    def clone_repo(self, repo: str, branch: str | None = None) -> Path:
        """Clone by org/repo name."""
        gh = self._get_github_client()
        try:
            gh_repo = gh.get_repo(repo)
            self._gh_repo = gh_repo
            return self.clone(gh_repo.clone_url, branch=branch)
        except GithubException as exc:
            if exc.status == 404:
                raise RepositoryNotFoundError(f"GitHub repository not found: {repo}") from exc
            raise AuthenticationError(f"GitHub API error: {exc}") from exc

    def create_pull_request(
        self,
        repo: str,
        branch: str,
        title: str,
        body: str,
        base_branch: str = "main",
    ) -> str:
        """Create a GitHub pull request and return its URL."""
        gh = self._get_github_client()
        try:
            gh_repo = gh.get_repo(repo)
            pr = gh_repo.create_pull(
                title=title,
                body=body,
                head=branch,
                base=base_branch,
                draft=False,
            )
            logger.info("Created GitHub PR #%d: %s", pr.number, pr.html_url)
            return pr.html_url
        except GithubException as exc:
            raise PullRequestError(f"Failed to create GitHub PR: {exc}") from exc

    def full_remediation_pipeline(
        self,
        repo: str,
        *,
        base_branch: str = "main",
        target_branch: str | None = None,
        create_pr: bool = True,
        dry_run: bool = False,
    ) -> dict:
        """
        Complete pipeline: clone → scan → CBOM → remediate → push → PR.
        """
        from quantumguard.core.orchestrator import Orchestrator
        from quantumguard.core.models import ScanTarget, RemediationPlan, SupportedAdapter
        from quantumguard.core.constants import DEFAULT_BRANCH_PREFIX

        branch = target_branch or f"{DEFAULT_BRANCH_PREFIX}-{repo.replace('/', '-')}"

        # 1. Clone
        work_dir = self.clone_repo(repo, branch=base_branch)
        logger.info("Cloned %s to %s", repo, work_dir)

        # 2. Create branch
        if not dry_run:
            self.create_branch(branch)

        # 3. Scan
        orchestrator = Orchestrator(config=self.config)
        target = ScanTarget(path=work_dir, adapter=SupportedAdapter.FILESYSTEM)
        scan_result = orchestrator.scan(target)

        if not scan_result.findings:
            logger.info("No findings — pipeline complete without PR")
            return {"scan": scan_result, "remediation": None, "pr_url": None}

        # 4. Remediate
        plan = RemediationPlan(
            scan_result_id=scan_result.id,
            findings=scan_result.findings,
            target_branch=branch,
            dry_run=dry_run,
        )
        remediation = orchestrator.remediate(plan, adapter_key="filesystem")

        # 4.5. Inject Dev Container configuration for Windows compatibility
        if not dry_run and remediation and remediation.files_modified:
            devcontainer_dir = work_dir / ".devcontainer"
            devcontainer_dir.mkdir(parents=True, exist_ok=True)
            
            dockerfile_path = devcontainer_dir / "Dockerfile"
            dockerfile_path.write_text(
                "FROM mcr.microsoft.com/devcontainers/python:1-3.11-bookworm\n\n"
                "# Install CMake and build tools for compiling C-dependencies like liboqs\n"
                "RUN rm -f /etc/apt/sources.list.d/yarn.list \\\n"
                "    && apt-get update && export DEBIAN_FRONTEND=noninteractive \\\n"
                "    && apt-get -y install --no-install-recommends cmake build-essential git\n"
            )
            
            devcontainer_json_path = devcontainer_dir / "devcontainer.json"
            devcontainer_json_path.write_text(
                "{\n"
                '\t"name": "QuantumGuard PQC Environment",\n'
                '\t"build": {\n'
                '\t\t"dockerfile": "Dockerfile"\n'
                '\t},\n'
                '\t"customizations": {\n'
                '\t\t"vscode": {\n'
                '\t\t\t"settings": {\n'
                '\t\t\t\t"python.defaultInterpreterPath": "/usr/local/bin/python"\n'
                '\t\t\t},\n'
                '\t\t\t"extensions": [\n'
                '\t\t\t\t"ms-python.python",\n'
                '\t\t\t\t"ms-python.vscode-pylance"\n'
                '\t\t\t]\n'
                '\t\t}\n'
                '\t},\n'
                '\t"postCreateCommand": "pip install -r requirements.txt || pip install -e .",\n'
                '\t"remoteUser": "vscode"\n'
                "}\n"
            )
            
            remediation.files_modified.extend([dockerfile_path, devcontainer_json_path])

        # 5. Commit & Push
        if not dry_run and remediation.files_modified:
            self.commit(
                message=plan.commit_message,
                paths=remediation.files_modified,
            )
            self.push(branch=branch)

        # 6. Create PR
        pr_url = None
        if create_pr and not dry_run and remediation.files_modified:
            formatted_findings = []
            for f in scan_result.findings[:20]:
                try:
                    rel_path = f.file.relative_to(work_dir)
                except ValueError:
                    rel_path = f.file.name
                formatted_findings.append(f"- `{rel_path}:{f.line}` — {f.description}")

            findings_summary = "\n".join(formatted_findings)
            body = DEFAULT_PR_BODY_TEMPLATE.format(
                findings_summary=findings_summary,
                version=VERSION,
            )
            pr_url = self.create_pull_request(
                repo=repo,
                branch=branch,
                title=DEFAULT_PR_TITLE,
                body=body,
                base_branch=base_branch,
            )
            remediation.pr_url = pr_url

        return {"scan": scan_result, "remediation": remediation, "pr_url": pr_url}
