"""
Azure DevOps adapter — stub for plugin-based extension.
"""
from __future__ import annotations

import logging

from quantumguard.adapters.git import GitAdapter
from quantumguard.core.config import QuantumGuardConfig
from quantumguard.core.exceptions import AuthenticationError, PullRequestError

logger = logging.getLogger(__name__)


class AzureDevOpsAdapter(GitAdapter):
    """Azure DevOps source adapter with PR support."""

    def __init__(self, config: QuantumGuardConfig) -> None:
        super().__init__(config)
        if not config.azure_pat or not config.azure_org_url:
            raise AuthenticationError(
                "Azure DevOps credentials not configured. "
                "Set QUANTUMGUARD_AZURE_PAT and QUANTUMGUARD_AZURE_ORG_URL."
            )
        self._pat = config.azure_pat.get_secret_value()
        self._org_url = config.azure_org_url.rstrip("/")

    def create_pull_request(
        self,
        repo: str,
        branch: str,
        title: str,
        body: str,
        base_branch: str = "main",
    ) -> str:
        import base64
        import httpx

        # repo format: project/repository
        project, repository = repo.split("/", 1)
        url = (
            f"{self._org_url}/{project}/_apis/git/repositories/"
            f"{repository}/pullrequests?api-version=7.1"
        )
        token_b64 = base64.b64encode(f":{self._pat}".encode()).decode()
        headers = {"Authorization": f"Basic {token_b64}", "Content-Type": "application/json"}
        payload = {
            "title": title,
            "description": body,
            "sourceRefName": f"refs/heads/{branch}",
            "targetRefName": f"refs/heads/{base_branch}",
        }
        response = httpx.post(url, json=payload, headers=headers)
        if response.status_code not in (200, 201):
            raise PullRequestError(f"Azure DevOps PR creation failed: {response.text}")
        data = response.json()
        return str(data.get("url", ""))
