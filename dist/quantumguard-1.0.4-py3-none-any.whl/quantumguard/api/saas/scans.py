"""
Scan history router — list/detail for the current user, and a CLI-facing
ingest endpoint that persists scans run outside the request/webhook flow.
"""
from __future__ import annotations

import hashlib
import logging
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from quantumguard.api.saas.database import get_db
from quantumguard.api.saas.dependencies import get_current_user
from quantumguard.api.saas.models import LicenseKey, Scan, User
from quantumguard.api.saas.schemas import (
    ScanDetailResponse,
    ScanIngestRequest,
    ScanSummaryResponse,
)
from quantumguard.core.models import Finding, ScanResult, ScanTarget

logger = logging.getLogger("quantumguard.api.saas.scans")
router = APIRouter(prefix="/api/v1/scans", tags=["scans"])


@router.get("/me", response_model=list[ScanSummaryResponse])
def list_my_scans(
    limit: int = 50,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> list[ScanSummaryResponse]:
    """Return recent scans for the current user."""
    scans = (
        db.query(Scan)
        .filter(Scan.user_id == current_user.id)
        .order_by(Scan.created_at.desc())
        .limit(min(limit, 200))
        .all()
    )
    return [ScanSummaryResponse.model_validate(s) for s in scans]


@router.get("/{scan_id}", response_model=ScanDetailResponse)
def get_scan_detail(
    scan_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> ScanDetailResponse:
    """Return one scan (owned by the current user) with its findings."""
    scan = (
        db.query(Scan)
        .filter(Scan.id == scan_id, Scan.user_id == current_user.id)
        .first()
    )
    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")
    return ScanDetailResponse.model_validate(scan)


@router.post("/ingest", response_model=ScanSummaryResponse, status_code=201)
def ingest_scan(
    body: ScanIngestRequest,
    db: Session = Depends(get_db),
) -> ScanSummaryResponse:
    """
    Called by the CLI right after a local/remote scan completes. Auth is via
    the license key in the body (the CLI has no user session/JWT), mirroring
    the license-key lookup already used by the webhook auth dependency.
    """
    from quantumguard.api.saas.license_keys import is_key_valid
    from quantumguard.api.saas.scan_history import record_scan

    key_hash = hashlib.sha256(body.license.encode()).hexdigest()
    db_key = db.query(LicenseKey).filter(LicenseKey.key_hash == key_hash).first()
    if not db_key or db_key.status != "active":
        raise HTTPException(status_code=401, detail="Invalid or revoked license key")

    if not is_key_valid(db_key, db):
        raise HTTPException(
            status_code=401,
            detail="Free trial key has expired. Upgrade to a paid plan to continue.",
        )

    now = datetime.now(timezone.utc)
    scan_result = ScanResult(
        target=ScanTarget(path=body.target_path or "."),
        findings=[Finding(**f) for f in body.findings],
        files_scanned=body.files_scanned,
        files_with_findings=body.files_with_findings,
        duration_seconds=body.duration_seconds,
        started_at=body.started_at or now,
        completed_at=body.completed_at or now,
    )

    scan = record_scan(
        db,
        scan_result=scan_result,
        user_id=db_key.user_id,
        license_key_id=db_key.id,
        source=body.source,
        provider=body.provider,
        repo=body.repo,
        branch=body.branch,
        pr_url=body.pr_url,
        status=body.status,
        error_message=body.error_message,
        redact_findings=body.local_only,
    )
    db_key.last_used_at = now
    db.commit()
    db.refresh(scan)
    return ScanSummaryResponse.model_validate(scan)
