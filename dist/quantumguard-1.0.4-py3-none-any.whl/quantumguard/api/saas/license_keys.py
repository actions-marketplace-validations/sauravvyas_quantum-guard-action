"""
License key management router.
"""
from __future__ import annotations

import secrets
import string
import hashlib
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from quantumguard.api.saas.database import get_db
from quantumguard.api.saas.dependencies import get_current_user
from quantumguard.api.saas.models import LicenseKey, Subscription, User
from quantumguard.api.saas.schemas import (
    CreateLicenseKeyRequest,
    LicenseKeyResponse,
    MessageResponse,
)

router = APIRouter(prefix="/api/v1/license-keys", tags=["license-keys"])

TRIAL_KEY_LIFETIME_DAYS = 15


def _generate_key() -> str:
    """Generate a cryptographically secure key in QG-XXXXXXXX-XXXXXXXX-XXXXXXXX format."""
    chars = string.ascii_uppercase + string.digits
    parts = ["".join(secrets.choice(chars) for _ in range(8)) for _ in range(3)]
    return "QG-" + "-".join(parts)


def _get_active_subscription(user: User, db: Session) -> Subscription | None:
    """The user's current subscription. A user can end up with more than one
    row in status active/trialing at once (e.g. the auto-provisioned free
    trial plus a later real paid one) — most-recently-created wins, so an
    upgrade always takes precedence over the original trial row."""
    return (
        db.query(Subscription)
        .filter(
            Subscription.user_id == user.id,
            Subscription.status.in_(["active", "trialing"]),
        )
        .order_by(Subscription.created_at.desc())
        .first()
    )


def _as_aware_utc(dt: datetime | None) -> datetime | None:
    """SQLite (used in tests) silently drops tz-awareness on
    DateTime(timezone=True) columns even though Postgres (production)
    preserves it — normalize so comparisons work the same on both."""
    if dt is None:
        return None
    return dt if dt.tzinfo is not None else dt.replace(tzinfo=timezone.utc)


def _is_paid_and_current(sub: Subscription | None) -> bool:
    """A subscription counts as 'paid' only if it costs money and its billing
    period hasn't lapsed — not just an active/trialing status flag. Checking
    price rather than `plan.name == "Trial"` avoids relying on a fragile
    string match against a plan name that could be renamed."""
    if sub is None or sub.plan is None:
        return False
    if sub.plan.price_monthly <= 0:
        return False
    period_end = _as_aware_utc(sub.current_period_end)
    if period_end is None:
        return False
    return period_end > datetime.now(timezone.utc)


def is_key_valid(key: LicenseKey, db: Session) -> bool:
    """
    Whether a license key currently works. Checked fresh every time (webhook
    auth, CLI verify, scan ingest) rather than baked into a stored expiry, so
    that upgrading mid-trial or cancelling a paid plan takes effect
    immediately without needing a scheduled job.
    """
    if key.status != "active":
        return False  # revocation is absolute — overrides everything below

    sub = _get_active_subscription(key.user, db)
    if _is_paid_and_current(sub):
        return True  # live paid subscription is the sole source of truth here

    # No live paid subscription right now — fall back to this key's own cutoff.
    expires_at = _as_aware_utc(key.expires_at)
    if expires_at is None:
        # Created under a paid plan that has since lapsed/cancelled — no grace.
        return False
    return datetime.now(timezone.utc) <= expires_at


@router.get("/verify", response_model=MessageResponse)
def verify_license_key(
    key: str,
    db: Session = Depends(get_db)
) -> MessageResponse:
    """Verify a license key (Used by the public CLI)."""
    key_hash = hashlib.sha256(key.encode()).hexdigest()
    db_key = db.query(LicenseKey).filter(LicenseKey.key_hash == key_hash).first()

    if not db_key or db_key.status != "active":
        raise HTTPException(status_code=401, detail="Invalid or revoked license key")

    if not is_key_valid(db_key, db):
        raise HTTPException(
            status_code=401,
            detail="Free trial key has expired. Upgrade to a paid plan to continue.",
        )

    return MessageResponse(message="License is valid")


@router.get("", response_model=list[LicenseKeyResponse])
def list_license_keys(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> list[LicenseKeyResponse]:
    """Return all license keys belonging to the current user."""
    keys = (
        db.query(LicenseKey)
        .filter(LicenseKey.user_id == current_user.id)
        .order_by(LicenseKey.created_at.desc())
        .all()
    )
    return [LicenseKeyResponse.model_validate(k) for k in keys]


def _provision_key(db: Session, user: User, name: str, is_paid: bool) -> LicenseKeyResponse:
    """Shared key-creation logic — generation, quota, trial expiry/claim
    stamping. Called both from `create_license_key` below (an existing
    subscription already in hand) and from the billing `start-trial`
    endpoint (which creates the subscription immediately before calling
    this in the same request)."""
    # Check key quota from the plan (Hardcoded to 1 globally)
    max_keys = 1

    active_count = (
        db.query(LicenseKey)
        .filter(LicenseKey.user_id == user.id, LicenseKey.status == "active")
        .count()
    )
    if active_count >= max_keys:
        raise HTTPException(
            status_code=403,
            detail=f"You are only allowed a maximum of {max_keys} active key(s). Revoke your existing key first.",
        )

    # Generate unique key
    for _ in range(10):
        key_str = _generate_key()
        key_hash = hashlib.sha256(key_str.encode()).hexdigest()
        if not db.query(LicenseKey).filter(LicenseKey.key_hash == key_hash).first():
            break
    else:
        raise HTTPException(status_code=500, detail="Could not generate a unique key, please retry")

    # The prefix is what we show in the UI later: "QG-ABCD..."
    key_display = key_str[:12] + "••••-••••"

    now = datetime.now(timezone.utc)
    new_key = LicenseKey(
        user_id=user.id,
        key_hash=key_hash,
        key_display=key_display,
        name=name,
        expires_at=None if is_paid else now + timedelta(days=TRIAL_KEY_LIFETIME_DAYS),
    )
    db.add(new_key)

    if not is_paid and user.trial_key_claimed_at is None:
        user.trial_key_claimed_at = now

    db.commit()
    db.refresh(new_key)

    # We must return the *full* key exactly once during creation.
    return LicenseKeyResponse(
        id=new_key.id,
        key=key_str,
        name=new_key.name,
        status=new_key.status,
        last_used_at=new_key.last_used_at,
        created_at=new_key.created_at,
        revoked_at=new_key.revoked_at,
        expires_at=new_key.expires_at,
    )


@router.post("", response_model=LicenseKeyResponse, status_code=201)
def create_license_key(
    body: CreateLicenseKeyRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> LicenseKeyResponse:
    """Create a new license key. Requires an active or trialing subscription."""
    sub = _get_active_subscription(current_user, db)
    if sub is None:
        raise HTTPException(
            status_code=402,
            detail="An active subscription is required to create license keys",
        )

    is_paid = _is_paid_and_current(sub)
    if not is_paid and current_user.trial_key_claimed_at is not None:
        raise HTTPException(
            status_code=403,
            detail="Free trial key already used on this account. Upgrade to a paid plan to create a new key.",
        )

    return _provision_key(db, current_user, body.name, is_paid)


@router.delete("/{key_id}", response_model=MessageResponse)
def revoke_license_key(
    key_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> MessageResponse:
    """Revoke (soft-delete) a license key."""
    key = (
        db.query(LicenseKey)
        .filter(LicenseKey.id == key_id, LicenseKey.user_id == current_user.id)
        .first()
    )
    if key is None:
        raise HTTPException(status_code=404, detail="License key not found")
    if key.status == "revoked":
        raise HTTPException(status_code=400, detail="Key is already revoked")

    key.status = "revoked"
    key.revoked_at = datetime.now(timezone.utc)
    db.commit()
    return MessageResponse(message="License key revoked successfully")
