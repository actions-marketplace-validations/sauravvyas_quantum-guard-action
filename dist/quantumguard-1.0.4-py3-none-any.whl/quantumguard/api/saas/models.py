"""
SQLAlchemy ORM models for the QuantumGuard SaaS layer.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import (
    Boolean, DateTime, Float, ForeignKey, Integer, String, Text, func
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from quantumguard.api.saas.database import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _uuid() -> str:
    return str(uuid.uuid4())


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    hashed_password: Mapped[str | None] = mapped_column(String(255), nullable=True)
    google_id: Mapped[str | None] = mapped_column(String(255), unique=True, nullable=True, index=True)
    auth_provider: Mapped[str] = mapped_column(String(50), default="local")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    stripe_customer_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)

    trial_key_claimed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    license_keys: Mapped[list[LicenseKey]] = relationship("LicenseKey", back_populates="user", cascade="all, delete-orphan")
    subscriptions: Mapped[list[Subscription]] = relationship("Subscription", back_populates="user", cascade="all, delete-orphan")
    usage_events: Mapped[list[UsageEvent]] = relationship("UsageEvent", back_populates="user", cascade="all, delete-orphan")
    scans: Mapped[list[Scan]] = relationship("Scan", back_populates="user", cascade="all, delete-orphan")


class Plan(Base):
    __tablename__ = "plans"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    name: Mapped[str] = mapped_column(String(100), nullable=False)          # e.g. "Starter", "Pro", "Enterprise"
    description: Mapped[str] = mapped_column(Text, default="")
    price_monthly: Mapped[float] = mapped_column(Float, default=0.0)
    price_yearly: Mapped[float] = mapped_column(Float, default=0.0)
    currency: Mapped[str] = mapped_column(String(3), default="USD")
    stripe_price_id_monthly: Mapped[str | None] = mapped_column(String(255), nullable=True)
    stripe_price_id_yearly: Mapped[str | None] = mapped_column(String(255), nullable=True)
    webhook_calls_per_month: Mapped[int] = mapped_column(Integer, default=100)
    max_license_keys: Mapped[int] = mapped_column(Integer, default=1)
    features: Mapped[str] = mapped_column(Text, default="[]")   # JSON list
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    subscriptions: Mapped[list[Subscription]] = relationship("Subscription", back_populates="plan")


class Subscription(Base):
    __tablename__ = "subscriptions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    plan_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("plans.id"), nullable=True)
    stripe_subscription_id: Mapped[str | None] = mapped_column(String(255), nullable=True, unique=True)
    stripe_customer_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    status: Mapped[str] = mapped_column(String(50), default="trialing")  # active, trialing, past_due, canceled, etc.
    current_period_start: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    current_period_end: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    cancel_at_period_end: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)

    user: Mapped[User] = relationship("User", back_populates="subscriptions")
    plan: Mapped[Plan | None] = relationship("Plan", back_populates="subscriptions")


class LicenseKey(Base):
    __tablename__ = "license_keys"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    key_hash: Mapped[str] = mapped_column(String(100), unique=True, nullable=False, index=True)
    key_display: Mapped[str] = mapped_column(String(100), nullable=False)
    name: Mapped[str] = mapped_column(String(255), default="Default")
    status: Mapped[str] = mapped_column(String(20), default="active")    # active | revoked
    last_used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    # NULL for a key created under a paid plan (validity is derived live from the
    # subscription instead); set to created_at + 15 days for a free-trial key.
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    user: Mapped[User] = relationship("User", back_populates="license_keys")

    @property
    def key(self) -> str:
        """Alias for key_display for backwards compatibility with Pydantic schemas."""
        return self.key_display


from sqlalchemy import Index

class UsageEvent(Base):
    __tablename__ = "usage_events"
    __table_args__ = (
        Index("ix_usage_user_time", "user_id", "created_at"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    license_key_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("license_keys.id"), nullable=True)
    event_type: Mapped[str] = mapped_column(String(50), default="webhook")    # webhook | scan | remediate
    provider: Mapped[str | None] = mapped_column(String(50), nullable=True)   # github, gitlab, bitbucket, azure
    repo: Mapped[str | None] = mapped_column(String(500), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="accepted")       # accepted | failed | ignored
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    user: Mapped[User] = relationship("User", back_populates="usage_events")


class Scan(Base):
    """One row per scan run (triggered via CLI or webhook remediation pipeline)."""

    __tablename__ = "scans"
    __table_args__ = (
        Index("ix_scans_user_time", "user_id", "created_at"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    license_key_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("license_keys.id"), nullable=True)
    source: Mapped[str] = mapped_column(String(20), default="cli")            # cli | webhook
    provider: Mapped[str | None] = mapped_column(String(50), nullable=True)   # github | gitlab | bitbucket | azure | filesystem
    repo: Mapped[str | None] = mapped_column(String(500), nullable=True)      # org/name, or local dir basename
    branch: Mapped[str | None] = mapped_column(String(255), nullable=True)
    target_path: Mapped[str] = mapped_column(String(1000), default="")
    status: Mapped[str] = mapped_column(String(20), default="running")       # running | completed | failed
    files_scanned: Mapped[int] = mapped_column(Integer, default=0)
    files_with_findings: Mapped[int] = mapped_column(Integer, default=0)
    total_findings: Mapped[int] = mapped_column(Integer, default=0)
    critical_count: Mapped[int] = mapped_column(Integer, default=0)
    high_count: Mapped[int] = mapped_column(Integer, default=0)
    medium_count: Mapped[int] = mapped_column(Integer, default=0)
    low_count: Mapped[int] = mapped_column(Integer, default=0)
    info_count: Mapped[int] = mapped_column(Integer, default=0)
    duration_seconds: Mapped[float] = mapped_column(Float, default=0.0)
    pr_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    user: Mapped[User] = relationship("User", back_populates="scans")
    findings: Mapped[list["ScanFinding"]] = relationship(
        "ScanFinding", back_populates="scan", cascade="all, delete-orphan"
    )


class ScanFinding(Base):
    """One row per finding produced by a scan (child of Scan)."""

    __tablename__ = "scan_findings"
    __table_args__ = (
        Index("ix_scan_findings_scan", "scan_id"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    scan_id: Mapped[str] = mapped_column(String(36), ForeignKey("scans.id"), nullable=False, index=True)
    rule_id: Mapped[str] = mapped_column(String(50), nullable=False)
    severity: Mapped[str] = mapped_column(String(20), nullable=False)   # CRITICAL | HIGH | MEDIUM | LOW | INFO
    algorithm: Mapped[str] = mapped_column(String(50), nullable=False)
    library: Mapped[str] = mapped_column(String(255), default="")
    file: Mapped[str] = mapped_column(String(1000), nullable=False)
    line: Mapped[int] = mapped_column(Integer, default=0)
    column: Mapped[int] = mapped_column(Integer, default=0)
    end_line: Mapped[int | None] = mapped_column(Integer, nullable=True)
    language: Mapped[str] = mapped_column(String(50), default="")
    recommendation: Mapped[str] = mapped_column(Text, default="")
    description: Mapped[str] = mapped_column(Text, default="")
    cwe: Mapped[str] = mapped_column(Text, default="[]")                # JSON list, string form
    confidence: Mapped[float] = mapped_column(Float, default=1.0)
    remediated: Mapped[bool] = mapped_column(Boolean, default=False)
    finding_metadata: Mapped[str] = mapped_column(Text, default="{}")   # JSON dict, string form
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    scan: Mapped[Scan] = relationship("Scan", back_populates="findings")
