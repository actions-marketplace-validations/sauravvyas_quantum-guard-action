"""
Pydantic schemas (request/response) for the QuantumGuard SaaS API.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, EmailStr, Field, field_validator


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

class RegisterRequest(BaseModel):
    name: str = Field(..., min_length=2, max_length=255)
    email: EmailStr
    password: str = Field(..., min_length=8, max_length=128)

    @field_validator("password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters")
        return v


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int = 3600


class UserResponse(BaseModel):
    id: str
    name: str
    email: str
    is_active: bool
    is_verified: bool
    created_at: datetime

    model_config = {"from_attributes": True}


class AuthResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int = 3600
    user: UserResponse


class UpdateProfileRequest(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=255)
    email: EmailStr | None = None


class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str = Field(..., min_length=8)


# ---------------------------------------------------------------------------
# Plans
# ---------------------------------------------------------------------------

class PlanResponse(BaseModel):
    id: str
    name: str
    description: str
    price_monthly: float
    price_yearly: float
    currency: str
    webhook_calls_per_month: int
    max_license_keys: int
    features: list[str]
    is_active: bool
    sort_order: int

    model_config = {"from_attributes": True}


# ---------------------------------------------------------------------------
# Subscriptions
# ---------------------------------------------------------------------------

class SubscriptionResponse(BaseModel):
    id: str
    status: str
    current_period_start: datetime | None
    current_period_end: datetime | None
    cancel_at_period_end: bool
    plan: PlanResponse | None
    created_at: datetime

    model_config = {"from_attributes": True}


# ---------------------------------------------------------------------------
# License Keys
# ---------------------------------------------------------------------------

class LicenseKeyResponse(BaseModel):
    id: str
    key: str
    name: str
    status: str
    last_used_at: datetime | None
    created_at: datetime
    revoked_at: datetime | None
    expires_at: datetime | None = None

    model_config = {"from_attributes": True}


class CreateLicenseKeyRequest(BaseModel):
    name: str = Field(default="Default", max_length=255)


# ---------------------------------------------------------------------------
# Billing / Stripe
# ---------------------------------------------------------------------------

class CreateCheckoutRequest(BaseModel):
    plan_id: str
    billing_interval: str = Field(default="monthly", pattern="^(monthly|yearly)$")
    success_url: str
    cancel_url: str


class CheckoutSessionResponse(BaseModel):
    checkout_url: str
    session_id: str


class CustomerPortalResponse(BaseModel):
    portal_url: str


class InvoiceResponse(BaseModel):
    id: str
    amount_paid: float
    currency: str
    status: str
    hosted_invoice_url: str | None
    created: datetime
    description: str | None


# ---------------------------------------------------------------------------
# Usage
# ---------------------------------------------------------------------------

class UsageSummaryResponse(BaseModel):
    requests_used: int
    requests_limit: int
    remaining: int
    usage_percent: float
    period_start: datetime | None
    period_end: datetime | None


class UsageEventResponse(BaseModel):
    id: str
    event_type: str
    provider: str | None
    repo: str | None
    status: str
    created_at: datetime

    model_config = {"from_attributes": True}


# ---------------------------------------------------------------------------
# Scans
# ---------------------------------------------------------------------------

class ScanFindingResponse(BaseModel):
    id: str
    rule_id: str
    severity: str
    algorithm: str
    library: str
    file: str
    line: int
    column: int
    end_line: int | None
    language: str
    recommendation: str
    description: str
    cwe: list[str]
    confidence: float
    remediated: bool
    created_at: datetime

    model_config = {"from_attributes": True}

    @field_validator("cwe", mode="before")
    @classmethod
    def _parse_cwe(cls, v: Any) -> list[str]:
        if isinstance(v, str):
            import json
            try:
                return json.loads(v)
            except ValueError:
                return []
        return v


class ScanSummaryResponse(BaseModel):
    id: str
    source: str
    provider: str | None
    repo: str | None
    branch: str | None
    target_path: str
    status: str
    files_scanned: int
    files_with_findings: int
    total_findings: int
    critical_count: int
    high_count: int
    medium_count: int
    low_count: int
    info_count: int
    duration_seconds: float
    pr_url: str | None
    started_at: datetime
    completed_at: datetime | None
    created_at: datetime

    model_config = {"from_attributes": True}


class ScanDetailResponse(ScanSummaryResponse):
    findings: list[ScanFindingResponse]


class ScanIngestRequest(BaseModel):
    """Payload the CLI POSTs after running a scan, authenticated via license key."""

    license: str
    source: str = "cli"
    provider: str | None = None
    repo: str | None = None
    branch: str | None = None
    target_path: str = ""
    status: str = "completed"        # completed | failed
    error_message: str | None = None
    pr_url: str | None = None
    local_only: bool = True          # if True, only summary counts are stored (no per-finding detail)
    files_scanned: int = 0
    files_with_findings: int = 0
    duration_seconds: float = 0.0
    started_at: datetime | None = None
    completed_at: datetime | None = None
    findings: list[dict[str, Any]] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Generic
# ---------------------------------------------------------------------------

class MessageResponse(BaseModel):
    message: str


class ErrorResponse(BaseModel):
    detail: str
    code: str | None = None
    extra: dict[str, Any] | None = None
