"""QuantumGuard SaaS API — user auth, billing, license keys, usage."""
