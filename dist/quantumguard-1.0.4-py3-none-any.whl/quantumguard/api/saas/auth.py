"""
Auth router: register, login, logout, me, update profile, change password.
"""
from __future__ import annotations

import logging
import threading
import time
from datetime import timedelta

import requests as http_requests
from fastapi import APIRouter, Depends, HTTPException, status, Response, Request
from fastapi.responses import RedirectResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session
from urllib.parse import urlencode
import os
import secrets

_ENV = os.environ.get("ENVIRONMENT", "development").lower()
_IS_PROD = _ENV == "production"

from quantumguard.api.saas.database import get_db
from quantumguard.api.saas.dependencies import get_current_user, bearer_scheme
from quantumguard.api.saas.models import User
from quantumguard.api.saas.schemas import (
    AuthResponse,
    ChangePasswordRequest,
    LoginRequest,
    MessageResponse,
    RegisterRequest,
    UpdateProfileRequest,
    UserResponse,
)
from quantumguard.api.saas.security import (
    ACCESS_TOKEN_EXPIRE_MINUTES,
    create_access_token,
    hash_password,
    verify_password,
)

logger = logging.getLogger("quantumguard.api.saas.auth")

def _get_google_client_id() -> str:
    return os.environ.get("QUANTUMGUARD_GOOGLE_CLIENT_ID", "")

def _get_google_client_secret() -> str:
    return os.environ.get("QUANTUMGUARD_GOOGLE_CLIENT_SECRET", "")

def _get_google_redirect_uri() -> str:
    return os.environ.get(
        "QUANTUMGUARD_GOOGLE_REDIRECT_URI",
        "http://localhost:8000/api/v1/auth/google/callback",
    )

def _get_frontend_url() -> str:
    return os.environ.get("QUANTUMGUARD_FRONTEND_URL", "http://localhost:5173")

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])

# ---------------------------------------------------------------------------
# In-memory OAuth state store — short-lived CSRF protection tokens
# {state_token: expiry_timestamp}
# ---------------------------------------------------------------------------
_oauth_states: dict[str, float] = {}
_states_lock = threading.Lock()
_STATE_TTL = 300  # 5 minutes


def _store_oauth_state(state: str) -> None:
    with _states_lock:
        # Clean up expired states
        now = time.monotonic()
        expired = [k for k, v in _oauth_states.items() if v < now]
        for k in expired:
            del _oauth_states[k]
        _oauth_states[state] = now + _STATE_TTL


def _consume_oauth_state(state: str) -> bool:
    """Returns True if state is valid and removes it (one-time use)."""
    with _states_lock:
        expiry = _oauth_states.pop(state, None)
        if expiry is None:
            return False
        return time.monotonic() < expiry


# ---------------------------------------------------------------------------
# In-memory short-lived code store for OAuth token exchange
# {code: jwt_token} — codes expire after 30 seconds, one-time use
# ---------------------------------------------------------------------------
_pending_codes: dict[str, tuple[str, float]] = {}
_codes_lock = threading.Lock()
_CODE_TTL = 30  # seconds


def _issue_exchange_code(token: str) -> str:
    code = secrets.token_urlsafe(32)
    with _codes_lock:
        now = time.monotonic()
        expired = [k for k, (_, exp) in _pending_codes.items() if exp < now]
        for k in expired:
            del _pending_codes[k]
        _pending_codes[code] = (token, now + _CODE_TTL)
    return code


def _consume_exchange_code(code: str) -> str | None:
    """Returns JWT token if code is valid, else None. Deletes code after use."""
    with _codes_lock:
        entry = _pending_codes.pop(code, None)
        if entry is None:
            return None
        token, expiry = entry
        if time.monotonic() > expiry:
            return None
        return token


# ---------------------------------------------------------------------------
# Auth endpoints
# ---------------------------------------------------------------------------

@router.post("/register", response_model=AuthResponse, status_code=201)
def register(body: RegisterRequest, response: Response, db: Session = Depends(get_db)) -> AuthResponse:
    """Register a new user account."""
    existing = db.query(User).filter(User.email == body.email.lower()).first()
    if existing:
        raise HTTPException(status_code=409, detail="An account with this email already exists")

    user = User(
        name=body.name.strip(),
        email=body.email.lower(),
        hashed_password=hash_password(body.password),
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    token = create_access_token(
        {"sub": user.id},
        expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES),
    )
    logger.info("New user registered: %s", user.id)
    response.set_cookie(
        key="access_token",
        value=token,
        httponly=True,
        secure=_IS_PROD,  # HTTPS only in prod
        samesite="none",
        max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )
    return AuthResponse(
        access_token=token,
        expires_in=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        user=UserResponse.model_validate(user),
    )


@router.post("/login", response_model=AuthResponse)
def login(body: LoginRequest, response: Response, db: Session = Depends(get_db)) -> AuthResponse:
    """Authenticate with email + password."""
    user = db.query(User).filter(User.email == body.email.lower()).first()
    if not user or not user.hashed_password or not verify_password(body.password, user.hashed_password):
        # Constant-time rejection — don't reveal whether email exists
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
        )
    if not user.is_active:
        raise HTTPException(status_code=403, detail="Account is inactive")

    token = create_access_token(
        {"sub": user.id},
        expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES),
    )
    logger.info("User logged in: %s", user.id)
    response.set_cookie(
        key="access_token",
        value=token,
        httponly=True,
        secure=_IS_PROD,
        samesite="none",
        max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )
    return AuthResponse(
        access_token=token,
        expires_in=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        user=UserResponse.model_validate(user),
    )


@router.post("/logout", response_model=MessageResponse)
def logout(
    request: Request,
    response: Response,
    current_user: User = Depends(get_current_user),
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
) -> MessageResponse:
    """Logout — client should discard the token and server adds it to blocklist."""
    from quantumguard.api.saas.security import decode_access_token, revoke_token
    
    token = request.cookies.get("access_token")
    if not token and credentials:
        token = credentials.credentials
        
    if token:
        payload = decode_access_token(token)
        if payload and "jti" in payload and "exp" in payload:
            revoke_token(payload["jti"], payload["exp"])
        
    response.delete_cookie("access_token", httponly=True, secure=_IS_PROD, samesite="none")
    logger.info("User logged out: %s", current_user.id)
    return MessageResponse(message="Logged out successfully")


@router.get("/me", response_model=UserResponse)
def get_me(current_user: User = Depends(get_current_user)) -> UserResponse:
    """Return the current authenticated user's profile."""
    return UserResponse.model_validate(current_user)


@router.put("/me", response_model=UserResponse)
def update_profile(
    body: UpdateProfileRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> UserResponse:
    """Update name and/or email."""
    if body.name is not None:
        current_user.name = body.name.strip()
    if body.email is not None:
        email_lower = body.email.lower()
        conflict = db.query(User).filter(User.email == email_lower, User.id != current_user.id).first()
        if conflict:
            raise HTTPException(status_code=409, detail="Email already in use")
        current_user.email = email_lower
    db.commit()
    db.refresh(current_user)
    return UserResponse.model_validate(current_user)


@router.put("/me/password", response_model=MessageResponse)
def change_password(
    body: ChangePasswordRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> MessageResponse:
    """Change password after verifying the current one."""
    if not current_user.hashed_password or not verify_password(body.current_password, current_user.hashed_password):
        raise HTTPException(status_code=400, detail="Current password is incorrect")
    current_user.hashed_password = hash_password(body.new_password)
    db.commit()
    logger.info("Password changed for user: %s", current_user.id)
    return MessageResponse(message="Password updated successfully")


# ---------------------------------------------------------------------------
# Google OAuth — Authorization Code Flow with CSRF state validation
# ---------------------------------------------------------------------------

@router.get("/google/login")
def google_login() -> RedirectResponse:
    """Redirect to Google OAuth consent screen."""
    client_id = _get_google_client_id()
    if not client_id:
        raise HTTPException(status_code=503, detail="Google authentication is not configured.")

    # Generate and store a CSRF state token
    state = secrets.token_urlsafe(32)
    _store_oauth_state(state)

    params = {
        "client_id": client_id,
        "redirect_uri": _get_google_redirect_uri(),
        "response_type": "code",
        "scope": "openid email profile",
        "state": state,
        "access_type": "offline",
        "prompt": "consent",
    }
    auth_url = f"https://accounts.google.com/o/oauth2/v2/auth?{urlencode(params)}"
    return RedirectResponse(auth_url)


@router.get("/google/callback")
def google_callback(
    code: str | None = None,
    error: str | None = None,
    state: str | None = None,
    db: Session = Depends(get_db),
) -> RedirectResponse:
    """Handle Google OAuth callback."""
    frontend_url = _get_frontend_url()

    # --- CSRF state validation ---
    if not state or not _consume_oauth_state(state):
        logger.warning("OAuth callback received with invalid or missing state")
        return RedirectResponse(f"{frontend_url}/login?error=invalid_state")

    if error or not code:
        return RedirectResponse(f"{frontend_url}/login?error=google_auth_failed")

    # Exchange code for tokens
    token_data = {
        "client_id": _get_google_client_id(),
        "client_secret": _get_google_client_secret(),
        "code": code,
        "grant_type": "authorization_code",
        "redirect_uri": _get_google_redirect_uri(),
    }
    try:
        token_res = http_requests.post(
            "https://oauth2.googleapis.com/token",
            data=token_data,
            timeout=10,
        )
    except Exception:
        logger.exception("Failed to contact Google token endpoint")
        return RedirectResponse(f"{frontend_url}/login?error=google_token_exchange_failed")

    if not token_res.ok:
        logger.warning("Google token exchange failed: %s", token_res.status_code)
        return RedirectResponse(f"{frontend_url}/login?error=google_token_exchange_failed")

    tokens = token_res.json()
    access_token = tokens.get("access_token")

    # Get user info from Google
    try:
        user_info_res = http_requests.get(
            "https://www.googleapis.com/oauth2/v2/userinfo",
            headers={"Authorization": f"Bearer {access_token}"},
            timeout=10,
        )
    except Exception:
        logger.exception("Failed to contact Google userinfo endpoint")
        return RedirectResponse(f"{frontend_url}/login?error=google_user_info_failed")

    if not user_info_res.ok:
        logger.warning("Google userinfo failed: %s", user_info_res.status_code)
        return RedirectResponse(f"{frontend_url}/login?error=google_user_info_failed")

    user_info = user_info_res.json()
    google_id = user_info.get("id")
    email = user_info.get("email", "").lower()
    name = user_info.get("name", "Google User")
    email_verified = user_info.get("verified_email", False)

    if not google_id or not email:
        return RedirectResponse(f"{frontend_url}/login?error=google_invalid_profile")

    if not email_verified:
        logger.warning("Google OAuth: unverified email for google_id %s", google_id)
        return RedirectResponse(f"{frontend_url}/login?error=google_email_not_verified")

    # Find user by Google ID only (no silent account linking by email)
    user = db.query(User).filter(User.google_id == google_id).first()

    if not user:
        # Check if email already exists as a local account
        existing_local = db.query(User).filter(User.email == email).first()
        if existing_local:
            # DO NOT silently link — direct user to link manually after password login
            logger.warning(
                "OAuth login attempted for existing local account %s. Manual linking required.",
                existing_local.id,
            )
            return RedirectResponse(
                f"{frontend_url}/login?error=account_exists_use_password"
            )

        # Create brand new user
        user = User(
            name=name,
            email=email,
            google_id=google_id,
            auth_provider="google",
            hashed_password=None,
            is_verified=True,
        )
        db.add(user)
        db.commit()
        db.refresh(user)
        logger.info("New user created via Google OAuth: %s", user.id)

    if not user.is_active:
        return RedirectResponse(f"{frontend_url}/login?error=account_inactive")

    # Issue QuantumGuard JWT
    qg_token = create_access_token(
        {"sub": user.id},
        expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES),
    )

    # FIX C1: Never put JWT in URL. Issue a short-lived one-time code instead.
    exchange_code = _issue_exchange_code(qg_token)
    logger.info("OAuth login successful for user: %s", user.id)
    return RedirectResponse(f"{frontend_url}/login/callback?code={exchange_code}")


@router.post("/google/exchange", response_model=AuthResponse)
def google_exchange(
    code: str,
    response: Response,
    db: Session = Depends(get_db),
) -> AuthResponse:
    """Exchange a short-lived OAuth code for a JWT. Code is one-time use and expires in 30s."""
    token = _consume_exchange_code(code)
    if not token:
        raise HTTPException(status_code=400, detail="Invalid or expired exchange code")

    # Decode to get user
    from quantumguard.api.saas.security import decode_access_token
    payload = decode_access_token(token)
    if not payload:
        raise HTTPException(status_code=400, detail="Invalid token in exchange")

    user_id = payload.get("sub")
    user = db.query(User).filter(User.id == str(user_id), User.is_active.is_(True)).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    response.set_cookie(
        key="access_token",
        value=token,
        httponly=True,
        secure=_IS_PROD,
        samesite="none",
        max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )
    return AuthResponse(
        access_token=token,
        expires_in=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        user=UserResponse.model_validate(user),
    )
