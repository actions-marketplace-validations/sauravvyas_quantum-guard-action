"""
Database setup for QuantumGuard SaaS layer.

Uses SQLite by default (QUANTUMGUARD_SAAS_DB_URL for override).
No impact on existing webhook functionality.
"""
from __future__ import annotations

import os
from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker, Session
from typing import Generator

# Default to SQLite stored alongside the service
_db_dir = Path.home() / ".quantumguard"
_db_dir.mkdir(parents=True, exist_ok=True)
_DB_URL = os.environ.get(
    "QUANTUMGUARD_SAAS_DB_URL",
    f"sqlite:///{_db_dir / 'saas.db'}",
)

# SQLite needs check_same_thread=False for FastAPI's thread-pool.
# Adding a timeout to allow concurrent reads to wait for any brief locks.
connect_args = {"check_same_thread": False, "timeout": 15} if _DB_URL.startswith("sqlite") else {}

engine = create_engine(_DB_URL, connect_args=connect_args)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class Base(DeclarativeBase):
    """Shared declarative base for all SaaS models."""


def get_db() -> Generator[Session, None, None]:
    """FastAPI dependency: yields a database session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db() -> None:
    """Create all tables. Call once at startup."""
    # import models so Base knows about them
    from quantumguard.api.saas import models as _  # noqa: F401
    Base.metadata.create_all(bind=engine)
