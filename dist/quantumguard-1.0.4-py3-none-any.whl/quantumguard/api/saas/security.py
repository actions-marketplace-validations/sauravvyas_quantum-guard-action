"""
Security utilities: password hashing and JWT token management.
"""
from __future__ import annotations

import logging
import os
import threading
import time
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from jose import JWTError, jwt
from passlib.context import CryptContext

logger = logging.getLogger("quantumguard.api.saas.security")

# ---------------------------------------------------------------------------
# Configuration (from environment)
# ---------------------------------------------------------------------------
SECRET_KEY = os.environ.get("QUANTUMGUARD_SAAS_SECRET_KEY", "")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.environ.get("QUANTUMGUARD_SAAS_TOKEN_EXPIRE_MINUTES", "60"))
ISSUER = "quantumguard-saas"
AUDIENCE = "quantumguard-users"

# Fail fast if no secret key is configured
_MIN_KEY_LENGTH = 32
if not SECRET_KEY or len(SECRET_KEY) < _MIN_KEY_LENGTH:
    if SECRET_KEY == "" or not SECRET_KEY:
        logger.warning(
            "QUANTUMGUARD_SAAS_SECRET_KEY is not set. "
            "Using insecure fallback — DO NOT use in production. "
            "Generate with: openssl rand -hex 32"
        )
        SECRET_KEY = "dev-only-insecure-key-do-not-use-in-production-replace-me"
    else:
        logger.warning(
            "QUANTUMGUARD_SAAS_SECRET_KEY is too short (< 32 chars). "
            "Generate with: openssl rand -hex 32"
        )

# ---------------------------------------------------------------------------
# Password hashing — bcrypt
# ---------------------------------------------------------------------------
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(plain: str) -> str:
    return pwd_context.hash(plain)


def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)


# ---------------------------------------------------------------------------
# JWT
# ---------------------------------------------------------------------------

def create_access_token(data: dict[str, Any], expires_delta: timedelta | None = None) -> str:
    to_encode = data.copy()
    now = datetime.now(timezone.utc)
    expire = now + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({
        "exp": expire,
        "iat": now,
        "iss": ISSUER,
        "aud": AUDIENCE,
        "jti": str(uuid.uuid4()),   # Unique token ID (enables future revocation)
        "type": "access",
    })
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def decode_access_token(token: str) -> dict[str, Any] | None:
    try:
        return jwt.decode(
            token,
            SECRET_KEY,
            algorithms=[ALGORITHM],   # Explicit allowlist — prevents alg=none attack
            audience=AUDIENCE,
            issuer=ISSUER,
        )
    except JWTError:
        return None

# ---------------------------------------------------------------------------
# Token Revocation (Blocklist)
# ---------------------------------------------------------------------------
_revoked_tokens: dict[str, float] = {}
_revocation_lock = threading.Lock()

def revoke_token(jti: str, expires_at: float) -> None:
    """Add a token to the blocklist until its natural expiration."""
    with _revocation_lock:
        now = time.monotonic()
        # Clean up blocklist
        expired = [k for k, v in _revoked_tokens.items() if v < now]
        for k in expired:
            del _revoked_tokens[k]
        
        # Add new token with calculated TTL
        ttl = expires_at - datetime.now(timezone.utc).timestamp()
        if ttl > 0:
            _revoked_tokens[jti] = now + ttl

def is_token_revoked(jti: str) -> bool:
    """Check if a token is in the blocklist."""
    with _revocation_lock:
        expiry = _revoked_tokens.get(jti)
        if not expiry:
            return False
        if time.monotonic() > expiry:
            del _revoked_tokens[jti]
            return False
        return True
