"""
Shared persistence for scan results.

Called from two places: the webhook background task (quantumguard/api/webhook.py)
and the CLI ingest endpoint (quantumguard/api/saas/scans.py, POST /ingest, called
by the CLI over HTTP since it has no direct DB access). Writes Scan + ScanFinding
rows, plus a UsageEvent row (the usage_events table previously had no writer).

Does not commit — the caller owns the transaction.
"""
from __future__ import annotations

import json
import logging
from typing import Any

from sqlalchemy.orm import Session

from quantumguard.api.saas.models import Scan, ScanFinding, UsageEvent

logger = logging.getLogger("quantumguard.api.saas.scan_history")


def _severity_counts(findings_by_severity: dict[str, list]) -> dict[str, int]:
    return {
        "critical_count": len(findings_by_severity.get("CRITICAL", [])),
        "high_count": len(findings_by_severity.get("HIGH", [])),
        "medium_count": len(findings_by_severity.get("MEDIUM", [])),
        "low_count": len(findings_by_severity.get("LOW", [])),
        "info_count": len(findings_by_severity.get("INFO", [])),
    }


def record_scan(
    db: Session,
    *,
    scan_result: Any,  # quantumguard.core.models.ScanResult — kept loosely typed to avoid a core<->api import cycle
    user_id: str,
    license_key_id: str | None,
    source: str,
    provider: str | None,
    repo: str | None,
    branch: str | None = None,
    pr_url: str | None = None,
    status: str = "completed",
    error_message: str | None = None,
    redact_findings: bool = False,
) -> Scan:
    """Persist a ScanResult (+ findings) and log a UsageEvent. Caller commits."""
    counts = _severity_counts(scan_result.findings_by_severity)

    scan = Scan(
        user_id=user_id,
        license_key_id=license_key_id,
        source=source,
        provider=provider,
        repo=repo,
        branch=branch,
        target_path=str(scan_result.target.path),
        status=status,
        files_scanned=scan_result.files_scanned,
        files_with_findings=scan_result.files_with_findings,
        total_findings=scan_result.total_findings,
        duration_seconds=scan_result.duration_seconds,
        pr_url=pr_url,
        error_message=error_message,
        started_at=scan_result.started_at,
        completed_at=scan_result.completed_at,
        **counts,
    )
    db.add(scan)
    db.flush()  # populate scan.id for the findings FK

    if not redact_findings:
        for f in scan_result.findings:
            db.add(
                ScanFinding(
                    scan_id=scan.id,
                    rule_id=f.rule_id,
                    severity=str(f.severity),
                    algorithm=str(f.algorithm),
                    library=f.library,
                    file=str(f.file),
                    line=f.line,
                    column=f.column,
                    end_line=f.end_line,
                    language=str(f.language),
                    recommendation=f.recommendation,
                    description=f.description,
                    cwe=json.dumps(f.cwe),
                    confidence=f.confidence,
                    remediated=f.remediated,
                    finding_metadata=json.dumps(f.metadata),
                )
            )

    db.add(
        UsageEvent(
            user_id=user_id,
            license_key_id=license_key_id,
            event_type="scan",
            provider=provider,
            repo=repo,
            status="accepted" if status == "completed" else "failed",
        )
    )

    return scan
