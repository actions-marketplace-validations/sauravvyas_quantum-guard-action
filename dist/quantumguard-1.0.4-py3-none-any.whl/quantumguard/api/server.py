"""
QuantumGuard Cloud API Server
Exposes the scanning and remediation engine via HTTP webhooks.
Run with: uvicorn quantumguard.api.server:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from quantumguard.api.webhook import router as webhook_router
from quantumguard.core.constants import VERSION

logger = logging.getLogger("quantumguard.api.server")

# ---------------------------------------------------------------------------
# FastAPI Application
# ---------------------------------------------------------------------------
app = FastAPI(
    title="QuantumGuard PQC API",
    description=(
        "Privacy-first Post-Quantum Cryptography (PQC) migration platform. "
        "Receives git push webhooks from GitHub, GitLab, Bitbucket, and Azure DevOps. "
        "Automatically scans for legacy RSA usage and raises a Pull Request "
        "migrating code to Hybrid PQC (RSA-3072 + ML-KEM-768)."
    ),
    version=VERSION,
    docs_url="/docs",
    redoc_url="/redoc",
)

# ---------------------------------------------------------------------------
# CORS Middleware
# ---------------------------------------------------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# Register Webhook Router
# ---------------------------------------------------------------------------
app.include_router(webhook_router)


# ---------------------------------------------------------------------------
# Health Check Routes
# ---------------------------------------------------------------------------
@app.get("/health", tags=["system"])
async def health_check() -> dict:
    """Liveness check — returns OK if the server is running."""
    return {"status": "ok", "service": "quantumguard-api", "version": VERSION}


@app.get("/", tags=["system"])
async def root() -> dict:
    """Root info endpoint."""
    return {
        "service": "QuantumGuard PQC API",
        "version": VERSION,
        "docs": "/docs",
        "webhooks": {
            "github":    "/api/v1/webhooks/github",
            "gitlab":    "/api/v1/webhooks/gitlab",
            "bitbucket": "/api/v1/webhooks/bitbucket",
            "azure":     "/api/v1/webhooks/azure",
        },
    }
