"""
QuantumGuard Cloud API Server — Full SaaS Edition

Extends the original webhook server with SaaS authentication, billing,
license key management, and usage tracking.

Run with:
  uvicorn quantumguard.api.server_saas:app --host 0.0.0.0 --port 8000 --reload
"""
from __future__ import annotations

import logging
import os
from dotenv import load_dotenv

# Load .env file before anything else
load_dotenv()

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

from quantumguard.api.webhook import router as webhook_router
from quantumguard.api.saas.auth import router as auth_router
from quantumguard.api.saas.billing import router as billing_router
from quantumguard.api.saas.license_keys import router as keys_router
from quantumguard.api.saas.usage import router as usage_router
from quantumguard.api.saas.scans import router as scans_router
from quantumguard.core.constants import VERSION

logger = logging.getLogger("quantumguard.api.server_saas")

# ---------------------------------------------------------------------------
# Environment
# ---------------------------------------------------------------------------
_ENV = os.environ.get("ENVIRONMENT", "development").lower()
_IS_PROD = _ENV == "production"

# ---------------------------------------------------------------------------
# Rate Limiter
# ---------------------------------------------------------------------------
limiter = Limiter(key_func=get_remote_address, default_limits=["200/minute"])

# ---------------------------------------------------------------------------
# FastAPI Application
# ---------------------------------------------------------------------------
app = FastAPI(
    title="QuantumGuard PQC API — SaaS Platform",
    description=(
        "Privacy-first Post-Quantum Cryptography (PQC) migration platform. "
        "SaaS layer with user authentication, billing, license key management, "
        "and webhook-based automatic PQC remediation."
    ),
    version=VERSION,
    # Disable interactive docs in production (security hardening)
    docs_url=None if _IS_PROD else "/docs",
    redoc_url=None if _IS_PROD else "/redoc",
)

# Attach rate limiter to app
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# ---------------------------------------------------------------------------
# Security Headers Middleware
# ---------------------------------------------------------------------------

@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    if _IS_PROD:
        response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains; preload"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "script-src 'self'; "
            "style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data: https:; "
            "font-src 'self'; "
            "connect-src 'self' https://api.stripe.com; "
            "frame-src https://js.stripe.com https://hooks.stripe.com; "
            "object-src 'none'; "
            "base-uri 'self';"
        )
    return response

# ---------------------------------------------------------------------------
# CORS — restrict to known origins only
# ---------------------------------------------------------------------------
_raw_origins = os.environ.get(
    "QUANTUMGUARD_SAAS_CORS_ORIGINS",
    "http://localhost:5173,http://localhost:5174,http://localhost:3000",
)
_allowed_origins = [o.strip() for o in _raw_origins.split(",") if o.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_origins=_allowed_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "Accept", "X-Requested-With"],
)

# ---------------------------------------------------------------------------
# Database initialisation + plan seeding
# ---------------------------------------------------------------------------

@app.on_event("startup")
def on_startup() -> None:
    from quantumguard.api.saas.database import init_db, SessionLocal
    from quantumguard.api.saas.seeder import seed_plans

    logger.info("Initialising SaaS database...")
    init_db()

    with SessionLocal() as db:
        seed_plans(db)
    logger.info("SaaS database ready")


# ---------------------------------------------------------------------------
# Routers
# ---------------------------------------------------------------------------
app.include_router(webhook_router)
app.include_router(auth_router)
app.include_router(billing_router)
app.include_router(keys_router)
app.include_router(usage_router)
app.include_router(scans_router)


# ---------------------------------------------------------------------------
# Health / root
# ---------------------------------------------------------------------------

@app.get("/health", tags=["system"])
async def health_check() -> dict:
    return {"status": "ok", "service": "quantumguard-saas-api", "version": VERSION}


@app.get("/", tags=["system"])
async def root() -> dict:
    return {
        "service": "QuantumGuard PQC SaaS API",
        "version": VERSION,
        "docs": "/docs" if not _IS_PROD else "disabled in production",
        "auth": {
            "register": "POST /api/v1/auth/register",
            "login":    "POST /api/v1/auth/login",
            "me":       "GET  /api/v1/auth/me",
        },
        "billing": {
            "plans":        "GET  /api/v1/billing/plans",
            "subscription": "GET  /api/v1/billing/subscription",
            "checkout":     "POST /api/v1/billing/checkout",
        },
        "license_keys": {
            "list":   "GET    /api/v1/license-keys",
            "create": "POST   /api/v1/license-keys",
            "revoke": "DELETE /api/v1/license-keys/{id}",
        },
        "webhooks": {
            "github":    "POST /api/v1/webhooks/github",
            "gitlab":    "POST /api/v1/webhooks/gitlab",
            "bitbucket": "POST /api/v1/webhooks/bitbucket",
            "azure":     "POST /api/v1/webhooks/azure",
        },
        "scans": {
            "list":   "GET  /api/v1/scans/me",
            "detail": "GET  /api/v1/scans/{id}",
            "ingest": "POST /api/v1/scans/ingest",
        },
    }
