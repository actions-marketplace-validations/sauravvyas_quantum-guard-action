"""
QuantumGuard Webhook Router — handles background git push events from:
  - GitHub App  (POST /api/v1/webhooks/github)
  - GitLab      (POST /api/v1/webhooks/gitlab)
  - Bitbucket   (POST /api/v1/webhooks/bitbucket)
  - Azure DevOps(POST /api/v1/webhooks/azure)
"""
from __future__ import annotations

import logging

import hmac
import hashlib
from fastapi import APIRouter, BackgroundTasks, Header, HTTPException, Request, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session

from quantumguard.api.saas.database import get_db
from quantumguard.api.saas.models import LicenseKey

from quantumguard.core.config import get_config
from quantumguard.core.licensing import TRIAL_KEY, LICENSE_PATTERN
from quantumguard.adapters.github import GitHubAdapter
from quantumguard.adapters.gitlab import GitLabAdapter
from quantumguard.adapters.bitbucket import BitbucketAdapter
from quantumguard.adapters.azure_devops import AzureDevOpsAdapter

logger = logging.getLogger("quantumguard.api.webhooks")
router = APIRouter(prefix="/api/v1/webhooks", tags=["webhooks"])


class WebhookResponse(BaseModel):
    status: str
    provider: str
    message: str


class WebhookAuth(BaseModel):
    """Resolved identity for an authenticated webhook request."""

    license: str
    user_id: str | None = None
    license_key_id: str | None = None


async def verify_webhook_auth(
    request: Request,
    license: str | None = None,
    x_hub_signature_256: str | None = Header(None, alias="X-Hub-Signature-256"),
    db: Session = Depends(get_db),
) -> WebhookAuth:
    """
    Hybrid Security:
    1. Require a valid license key via query param: ?license=QG-TRIAL...
    2. Check the license key against the database using its SHA256 hash.
    3. If GitHub sends a signature, verify it using the license key as the HMAC secret.
    """
    if not license:
        raise HTTPException(status_code=401, detail="Missing ?license= query parameter")

    if license != TRIAL_KEY and not LICENSE_PATTERN.match(license):
        raise HTTPException(status_code=401, detail="Invalid license key format")

    user_id: str | None = None
    license_key_id: str | None = None

    if license != TRIAL_KEY:
        license_hash = hashlib.sha256(license.encode()).hexdigest()
        db_key = db.query(LicenseKey).filter(
            LicenseKey.key_hash == license_hash,
            LicenseKey.status == "active"
        ).first()

        if not db_key:
            raise HTTPException(status_code=401, detail="Invalid or revoked license key")

        from quantumguard.api.saas.license_keys import is_key_valid
        if not is_key_valid(db_key, db):
            raise HTTPException(
                status_code=401,
                detail="Free trial key has expired. Upgrade to a paid plan to continue.",
            )

        # Trial key (no DB row) is anonymous/offline by design — no user to attribute
        # a persisted scan to, so scan-history recording is skipped for it downstream.
        user_id = db_key.user_id
        license_key_id = db_key.id

    if x_hub_signature_256:
        body = await request.body()
        expected_signature = "sha256=" + hmac.new(license.encode(), body, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected_signature, x_hub_signature_256):
            logger.warning("Webhook signature mismatch for license %s", license)
            raise HTTPException(status_code=401, detail="HMAC signature verification failed")

    return WebhookAuth(license=license, user_id=user_id, license_key_id=license_key_id)


def _persist_webhook_scan(
    scan_result,
    *,
    user_id: str,
    license_key_id: str | None,
    provider: str,
    repo: str,
    pr_url: str | None,
    status: str,
    error_message: str | None = None,
) -> None:
    """Persist a scan from the webhook flow. Never raises — a DB hiccup must
    not affect the already-completed remediation/PR flow."""
    from quantumguard.api.saas.database import SessionLocal
    from quantumguard.api.saas.scan_history import record_scan

    try:
        with SessionLocal() as db:
            record_scan(
                db,
                scan_result=scan_result,
                user_id=user_id,
                license_key_id=license_key_id,
                source="webhook",
                provider=provider,
                repo=repo,
                pr_url=pr_url,
                status=status,
                error_message=error_message,
            )
            db.commit()
    except Exception:
        logger.exception("Failed to persist scan history for %s/%s", provider, repo)


def run_remediation_task(
    provider: str,
    repo: str,
    base_branch: str = "main",
    user_id: str | None = None,
    license_key_id: str | None = None,
) -> None:
    """Background worker: clone -> scan -> remediate -> push PR."""
    # Bootstrap all plugins (registers filesystem adapter, engines, etc.)
    from quantumguard.plugins import bootstrap
    bootstrap()

    config = get_config()
    logger.info("Starting remediation for [%s] repo: %s", provider, repo)
    try:
        if provider == "github":
            with GitHubAdapter(config=config) as adapter:
                result = adapter.full_remediation_pipeline(repo=repo, base_branch=base_branch, create_pr=True)
        elif provider == "gitlab":
            with GitLabAdapter(config=config) as adapter:
                result = adapter.full_remediation_pipeline(repo=repo, base_branch=base_branch, create_pr=True)
        elif provider == "bitbucket":
            with BitbucketAdapter(config=config) as adapter:
                result = adapter.full_remediation_pipeline(repo=repo, base_branch=base_branch, create_pr=True)
        elif provider == "azure":
            with AzureDevOpsAdapter(config=config) as adapter:
                result = adapter.full_remediation_pipeline(repo=repo, base_branch=base_branch, create_pr=True)
        else:
            result = None
        logger.info("Remediation completed for [%s] repo: %s", provider, repo)

        # Trial key requests have no associated user (anonymous/offline by design) — skip persistence.
        if user_id and result:
            _persist_webhook_scan(
                result["scan"],
                user_id=user_id,
                license_key_id=license_key_id,
                provider=provider,
                repo=repo,
                pr_url=result.get("pr_url"),
                status="completed",
            )
    except Exception as exc:
        logger.error("Remediation failed for [%s] %s: %s", provider, repo, exc, exc_info=True)


# ---------------------------------------------------------------------------
# GitHub Webhook
# ---------------------------------------------------------------------------
@router.post("/github", response_model=WebhookResponse)
async def handle_github_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    x_github_event: str = Header(..., alias="X-GitHub-Event"),
    valid_license: WebhookAuth = Depends(verify_webhook_auth),
) -> WebhookResponse:
    """Handle GitHub push events."""
    payload = await request.json()

    if x_github_event != "push":
        return WebhookResponse(status="ignored", provider="github", message=f"Event '{x_github_event}' ignored")

    repo = payload.get("repository", {}).get("full_name")
    if not repo:
        raise HTTPException(status_code=400, detail="Missing repository.full_name in payload")

    default_branch = payload.get("repository", {}).get("default_branch", "main")
    background_tasks.add_task(
        run_remediation_task, "github", repo, default_branch,
        valid_license.user_id, valid_license.license_key_id,
    )

    return WebhookResponse(
        status="accepted",
        provider="github",
        message=f"Queued PQC remediation for GitHub repo: {repo}",
    )


# ---------------------------------------------------------------------------
# GitLab Webhook
# ---------------------------------------------------------------------------
@router.post("/gitlab", response_model=WebhookResponse)
async def handle_gitlab_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    x_gitlab_event: str = Header(..., alias="X-Gitlab-Event"),
    valid_license: WebhookAuth = Depends(verify_webhook_auth),
) -> WebhookResponse:
    """Handle GitLab push events."""
    payload = await request.json()

    if x_gitlab_event != "Push Hook":
        return WebhookResponse(status="ignored", provider="gitlab", message=f"Event '{x_gitlab_event}' ignored")

    repo = payload.get("project", {}).get("path_with_namespace")
    if not repo:
        raise HTTPException(status_code=400, detail="Missing project.path_with_namespace in payload")

    default_branch = payload.get("project", {}).get("default_branch", "main")
    background_tasks.add_task(
        run_remediation_task, "gitlab", repo, default_branch,
        valid_license.user_id, valid_license.license_key_id,
    )

    return WebhookResponse(
        status="accepted",
        provider="gitlab",
        message=f"Queued PQC remediation for GitLab project: {repo}",
    )


# ---------------------------------------------------------------------------
# Bitbucket Webhook
# ---------------------------------------------------------------------------
@router.post("/bitbucket", response_model=WebhookResponse)
async def handle_bitbucket_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    x_event_key: str = Header(..., alias="X-Event-Key"),
    valid_license: WebhookAuth = Depends(verify_webhook_auth),
) -> WebhookResponse:
    """Handle Bitbucket push events."""
    payload = await request.json()

    if x_event_key != "repo:push":
        return WebhookResponse(status="ignored", provider="bitbucket", message=f"Event '{x_event_key}' ignored")

    repo = payload.get("repository", {}).get("full_name")
    if not repo:
        raise HTTPException(status_code=400, detail="Missing repository.full_name in payload")

    background_tasks.add_task(
        run_remediation_task, "bitbucket", repo, "main",
        valid_license.user_id, valid_license.license_key_id,
    )

    return WebhookResponse(
        status="accepted",
        provider="bitbucket",
        message=f"Queued PQC remediation for Bitbucket repo: {repo}",
    )


# ---------------------------------------------------------------------------
# Azure DevOps Service Hook
# ---------------------------------------------------------------------------
@router.post("/azure", response_model=WebhookResponse)
async def handle_azure_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    valid_license: WebhookAuth = Depends(verify_webhook_auth),
) -> WebhookResponse:
    """Handle Azure DevOps git.push events."""
    payload = await request.json()

    event_type = payload.get("eventType")
    if event_type != "git.push":
        return WebhookResponse(status="ignored", provider="azure", message=f"Event '{event_type}' ignored")

    repo = payload.get("resource", {}).get("repository", {}).get("name")
    if not repo:
        raise HTTPException(status_code=400, detail="Missing resource.repository.name in payload")

    background_tasks.add_task(
        run_remediation_task, "azure", repo, "main",
        valid_license.user_id, valid_license.license_key_id,
    )

    return WebhookResponse(
        status="accepted",
        provider="azure",
        message=f"Queued PQC remediation for Azure DevOps repo: {repo}",
    )
