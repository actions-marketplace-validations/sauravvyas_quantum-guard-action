"""
CBOM Schema constants and templates.
"""
from __future__ import annotations

CYCLONEDX_SCHEMA_VERSION = "1.6"
CYCLONEDX_SCHEMA_URL = "https://cyclonedx.org/schema/bom-1.6.schema.json"

CBOM_COMPONENT_TEMPLATE = {
    "type": "library",
    "bom-ref": "",
    "name": "",
    "purl": "",
    "description": "",
}

CBOM_ALGORITHM_TEMPLATE = {
    "type": "cryptoAsset",
    "bom-ref": "",
    "name": "",
    "cryptoProperties": {
        "assetType": "algorithm",
        "algorithmProperties": {
            "primitive": "",
            "implementationLevel": "softwarePlainRam",
            "nistQuantumSecurityLevel": 0,
        },
    },
}

# NIST PQC standardized algorithms (FIPS 203/204/205)
NIST_PQC_ALGORITHMS = {
    "ML-KEM": {
        "oid": "2.16.840.1.101.3.4.4.1",
        "fips": "FIPS 203",
        "quantum_security_level": 3,
        "variants": ["ML-KEM-512", "ML-KEM-768", "ML-KEM-1024"],
    },
    "ML-DSA": {
        "oid": "2.16.840.1.101.3.4.3.17",
        "fips": "FIPS 204",
        "quantum_security_level": 3,
        "variants": ["ML-DSA-44", "ML-DSA-65", "ML-DSA-87"],
    },
    "SLH-DSA": {
        "oid": "2.16.840.1.101.3.4.3.20",
        "fips": "FIPS 205",
        "quantum_security_level": 1,
        "variants": ["SLH-DSA-SHAKE-128s", "SLH-DSA-SHAKE-128f"],
    },
}

# Quantum-vulnerable classical algorithms
QUANTUM_VULNERABLE_ALGORITHMS = {
    "RSA": {"cwe": "CWE-1240", "nist_quantum_level": 0},
    "DSA": {"cwe": "CWE-1240", "nist_quantum_level": 0},
    "ECDSA": {"cwe": "CWE-1240", "nist_quantum_level": 0},
    "DH": {"cwe": "CWE-1240", "nist_quantum_level": 0},
}
