"""
CycloneDX 1.6 CBOM Generator.

Generates valid CycloneDX JSON Cryptographic Bill of Materials from scan results.

Spec reference: https://cyclonedx.org/specification/overview/
"""
from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from quantumguard.cbom.schemas import (
    CYCLONEDX_SCHEMA_VERSION,
    CBOM_COMPONENT_TEMPLATE,
    CBOM_ALGORITHM_TEMPLATE,
)
from quantumguard.core.constants import CBOM_FORMAT, CBOM_SPEC_VERSION, VERSION
from quantumguard.core.models import Finding, ScanResult


class CBOMGenerator:
    """
    Generates CycloneDX 1.6 compatible CBOM documents.

    Output includes:
      - metadata (tool, timestamp)
      - components (libraries detected)
      - cryptographic assets (algorithms found)
      - vulnerabilities (findings mapped to CWEs)
      - dependencies
    """

    def generate(self, scan_result: ScanResult) -> dict[str, Any]:
        """Generate a full CBOM from a scan result."""
        serial = f"urn:uuid:{uuid.uuid4()}"
        now = datetime.now(timezone.utc).isoformat()

        cbom: dict[str, Any] = {
            "bomFormat": CBOM_FORMAT,
            "specVersion": CBOM_SPEC_VERSION,
            "serialNumber": serial,
            "version": 1,
            "metadata": self._build_metadata(now, scan_result),
            "components": self._build_components(scan_result.findings),
            "cryptographyAssets": self._build_crypto_assets(scan_result.findings),
            "vulnerabilities": self._build_vulnerabilities(scan_result.findings),
            "dependencies": self._build_dependencies(scan_result.findings),
        }

        return cbom

    def generate_json(self, scan_result: ScanResult, indent: int = 2) -> str:
        """Generate CBOM as formatted JSON string."""
        return json.dumps(self.generate(scan_result), indent=indent, default=str)

    def save(self, scan_result: ScanResult, output_path: Path) -> Path:
        """Save CBOM to a JSON file."""
        output_path.parent.mkdir(parents=True, exist_ok=True)
        json_str = self.generate_json(scan_result)
        output_path.write_text(json_str, encoding="utf-8")
        return output_path

    def _build_metadata(self, timestamp: str, scan_result: ScanResult) -> dict[str, Any]:
        return {
            "timestamp": timestamp,
            "tools": [
                {
                    "vendor": "QuantumGuard",
                    "name": "QuantumGuard CLI",
                    "version": VERSION,
                    "externalReferences": [
                        {
                            "type": "website",
                            "url": "https://quantumguard.io",
                        }
                    ],
                }
            ],
            "component": {
                "type": "application",
                "name": str(scan_result.target.path.name),
                "bom-ref": f"target-{scan_result.id}",
            },
            "properties": [
                {"name": "quantumguard:scan_id", "value": scan_result.id},
                {"name": "quantumguard:files_scanned", "value": str(scan_result.files_scanned)},
                {"name": "quantumguard:total_findings", "value": str(scan_result.total_findings)},
                {"name": "quantumguard:privacy_mode", "value": "true"},
            ],
        }

    def _build_components(self, findings: list[Finding]) -> list[dict[str, Any]]:
        """Deduplicate libraries and build component entries."""
        seen_libs: dict[str, dict[str, Any]] = {}

        for finding in findings:
            lib = finding.library
            if lib not in seen_libs:
                bom_ref = f"lib-{lib}-{uuid.uuid4().hex[:8]}"
                seen_libs[lib] = {
                    "type": "library",
                    "bom-ref": bom_ref,
                    "name": lib,
                    "purl": f"pkg:pypi/{lib}",
                    "description": f"Cryptographic library: {lib}",
                    "properties": [
                        {"name": "quantumguard:quantum_vulnerable", "value": "true"},
                    ],
                }

        return list(seen_libs.values())

    def _build_crypto_assets(self, findings: list[Finding]) -> list[dict[str, Any]]:
        """Build cryptographic asset entries."""
        seen_algos: dict[str, dict[str, Any]] = {}

        for finding in findings:
            algo = str(finding.algorithm)
            key = f"{algo}-{finding.library}"

            if key not in seen_algos:
                bom_ref = f"algo-{algo}-{uuid.uuid4().hex[:8]}"
                seen_algos[key] = {
                    "type": "cryptoAsset",
                    "bom-ref": bom_ref,
                    "name": algo,
                    "cryptoProperties": {
                        "assetType": "algorithm",
                        "algorithmProperties": {
                            "primitive": algo.lower(),
                            "implementationLevel": "softwarePlainRam",
                            "implementationPlatform": "x86_64",
                            "certificationLevel": ["none"],
                            "cryptoFunctions": ["keyGeneration", "encapsulation", "decapsulation"],
                            "nistQuantumSecurityLevel": 0,  # quantum-vulnerable
                        },
                        "oid": self._get_oid(algo),
                    },
                    "relatedCryptoMaterialProperties": [],
                    "findings": [],
                }

            # Attach finding ref
            seen_algos[key]["findings"].append(
                {
                    "ref": f"finding-{finding.id[:8]}",
                    "file": str(finding.file),
                    "line": finding.line,
                    "severity": str(finding.severity),
                }
            )

        return list(seen_algos.values())

    def _build_vulnerabilities(self, findings: list[Finding]) -> list[dict[str, Any]]:
        """Map findings to CycloneDX vulnerability entries."""
        vulns = []
        for finding in findings:
            vuln: dict[str, Any] = {
                "bom-ref": f"vuln-{finding.id[:8]}",
                "id": f"QUANTUMGUARD-{finding.rule_id}",
                "source": {
                    "name": "QuantumGuard",
                    "url": f"https://quantumguard.io/rules/{finding.rule_id}",
                },
                "ratings": [
                    {
                        "source": {"name": "QuantumGuard"},
                        "severity": str(finding.severity).lower(),
                        "method": "other",
                    }
                ],
                "cwes": [int(cwe.replace("CWE-", "")) for cwe in finding.cwe if cwe.startswith("CWE-")],
                "description": finding.description,
                "recommendation": finding.recommendation,
                "affects": [
                    {
                        "ref": str(finding.file),
                        "versions": [
                            {
                                "version": "current",
                                "status": "affected",
                            }
                        ],
                    }
                ],
                "properties": [
                    {"name": "quantumguard:line", "value": str(finding.line)},
                    {"name": "quantumguard:column", "value": str(finding.column)},
                    {"name": "quantumguard:library", "value": finding.library},
                    {"name": "quantumguard:rule_id", "value": finding.rule_id},
                ],
            }
            vulns.append(vuln)
        return vulns

    def _build_dependencies(self, findings: list[Finding]) -> list[dict[str, Any]]:
        """Build dependency graph entries."""
        libs = {f.library for f in findings}
        return [
            {
                "ref": f"lib-{lib}",
                "dependsOn": [],
            }
            for lib in libs
        ]

    @staticmethod
    def _get_oid(algorithm: str) -> str:
        """Return OID for common algorithms."""
        oids = {
            "RSA": "1.2.840.113549.1.1.1",
            "DSA": "1.2.840.10040.4.1",
            "ECDSA": "1.2.840.10045.4",
            "SHA1": "1.3.14.3.2.26",
            "MD5": "1.2.840.113549.2.5",
        }
        return oids.get(algorithm, "")
