"""
QuantumGuard - Privacy-first Post-Quantum Cryptography Migration Platform.

Discovers legacy cryptography and automates migration to Hybrid PQC.
Source code never leaves the machine.
"""

__version__ = "1.0.0"
__author__ = "QuantumGuard"
__license__ = "MIT"

from quantumguard.core.registry import (
    ENGINE_REGISTRY,
    ADAPTER_REGISTRY,
    REMEDIATOR_REGISTRY,
    register_engine,
    register_adapter,
    register_remediator,
)

__all__ = [
    "__version__",
    "ENGINE_REGISTRY",
    "ADAPTER_REGISTRY",
    "REMEDIATOR_REGISTRY",
    "register_engine",
    "register_adapter",
    "register_remediator",
]
