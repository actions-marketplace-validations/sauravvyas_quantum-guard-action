import os
import re
from pathlib import Path

# Path to local license configuration
LICENSE_DIR = Path.home() / ".quantumguard"
LICENSE_FILE = LICENSE_DIR / "license.key"

# Regular expression matching key pattern: QG-[A-Z0-9]{8}-[A-Z0-9]{8}-[A-Z0-9]{8}
LICENSE_PATTERN = re.compile(r"^QG-[A-Z0-9]{8}-[A-Z0-9]{8}-[A-Z0-9]{8}$")

# Test trial key that is accepted offline
TRIAL_KEY = "QG-TRIAL-2026-ACTIVE"

def get_license_key() -> str | None:
    """Retrieves the license key from env or local config file."""
    # 1. Check environment variable first
    env_key = os.environ.get("QUANTUMGUARD_LICENSE_KEY")
    if env_key:
        return env_key.strip()

    # 2. Check local license file in ~/.quantumguard/license.key
    if LICENSE_FILE.exists():
        try:
            return LICENSE_FILE.read_text(encoding="utf-8").strip()
        except Exception:
            pass

    return None

def save_license_key(key: str) -> bool:
    """Saves the license key to the user's home configuration directory."""
    try:
        LICENSE_DIR.mkdir(parents=True, exist_ok=True)
        LICENSE_FILE.write_text(key.strip(), encoding="utf-8")
        return True
    except Exception:
        return False

def verify_license() -> tuple[bool, str]:
    """
    Verifies if the license key is valid.
    Returns (is_valid, message).
    """
    # SAAS BYPASS: If running inside the Webhook server, skip HTTP check to prevent recursive calls.
    if os.environ.get("QUANTUMGUARD_SAAS_MODE") == "true":
        return True, "SaaS Mode Active (Bypassing CLI HTTP check)"

    key = get_license_key()
    if not key:
        return False, (
            "No license key found.\n"
            "Please authenticate the CLI using:\n"
            "  quantumguard auth \"your-license-key\"\n"
            "or set the environment variable:\n"
            "  export QUANTUMGUARD_LICENSE_KEY=\"your-key-here\""
        )

    # Allow our trial key
    if key == TRIAL_KEY:
        return True, "Valid Trial License (Expires Dec 31, 2026)"

    # Validate pattern match (e.g. QG-ABCD-1234-WXYZ)
    if not LICENSE_PATTERN.match(key):
        return False, f"Invalid license key format: '{key}'. Please check your key."

    # Live HTTP Check against the backend
    import httpx
    saas_url = os.environ.get("QUANTUMGUARD_SAAS_URL", "http://localhost:8000").rstrip("/")
    try:
        res = httpx.get(f"{saas_url}/api/v1/license-keys/verify", params={"key": key}, timeout=60.0)
        if res.status_code == 200:
            return True, f"Valid License (Key: {key})"
        elif res.status_code == 401:
            return False, f"License Invalid or Expired: {res.json().get('detail', 'Unauthorized')}"
        else:
            return False, f"License verification failed (Server returned {res.status_code})"
    except httpx.RequestError as exc:
        return False, f"Could not reach QuantumGuard License Server: {exc}"
