"""
Rich-powered reporter for displaying scan results and CBOM output.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from rich import print as rprint
from rich.console import Console
from rich.panel import Panel
from rich.progress import BarColumn, Progress, SpinnerColumn, TaskProgressColumn, TextColumn
from rich.table import Table
from rich.text import Text
from rich.theme import Theme

from quantumguard.core.models import RemediationResult, ScanResult, Severity, SystemHealth

THEME = Theme(
    {
        "critical": "bold red",
        "high": "red",
        "medium": "yellow",
        "low": "cyan",
        "info": "dim",
        "success": "bold green",
        "warning": "yellow",
        "header": "bold blue",
        "pqc": "bold magenta",
    }
)

console = Console(theme=THEME)

SEVERITY_COLORS = {
    "CRITICAL": "[critical]",
    "HIGH": "[high]",
    "MEDIUM": "[medium]",
    "LOW": "[low]",
    "INFO": "[info]",
}


class Reporter:
    """Rich-powered CLI reporter."""

    def __init__(self, console: Console | None = None) -> None:
        self.console = console or Console(theme=THEME)

    def print_banner(self) -> None:
        from quantumguard.core.constants import VERSION

        banner = Text()
        banner.append("  ██████╗ ██╗   ██╗ █████╗ ███╗   ██╗████████╗██╗   ██╗███╗   ███╗\n", style="bold blue")
        banner.append(" ██╔═══██╗██║   ██║██╔══██╗████╗  ██║╚══██╔══╝██║   ██║████╗ ████║\n", style="bold blue")
        banner.append(" ██║   ██║██║   ██║███████║██╔██╗ ██║   ██║   ██║   ██║██╔████╔██║\n", style="bold cyan")
        banner.append(" ██║▄▄ ██║██║   ██║██╔══██║██║╚██╗██║   ██║   ██║   ██║██║╚██╔╝██║\n", style="bold cyan")
        banner.append(" ╚██████╔╝╚██████╔╝██║  ██║██║ ╚████║   ██║   ╚██████╔╝██║ ╚═╝ ██║\n", style="bold magenta")
        banner.append("  ╚══▀▀═╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝   ╚═╝    ╚═════╝ ╚═╝     ╚═╝\n", style="bold magenta")
        banner.append(f"                     GUARD  🔐  v{VERSION} — Privacy-First PQC Migration\n", style="dim")

        self.console.print(Panel(banner, border_style="blue", padding=(0, 2)))

    def print_scan_summary(self, result: ScanResult) -> None:
        self.console.print()
        self.console.print(Panel("[header]📊 Scan Results[/header]", border_style="blue"))

        # Summary table
        summary = Table(show_header=False, box=None, padding=(0, 2))
        summary.add_column("Key", style="dim")
        summary.add_column("Value", style="bold")
        summary.add_row("Target", str(result.target.path))
        summary.add_row("Files scanned", str(result.files_scanned))
        summary.add_row("Files with findings", str(result.files_with_findings))
        summary.add_row("Total findings", str(result.total_findings))
        summary.add_row("Duration", f"{result.duration_seconds:.2f}s")
        self.console.print(summary)
        self.console.print()

        if not result.findings:
            self.console.print("[success]✅ No cryptographic issues found![/success]")
            return

        # Findings by severity
        sev_table = Table(title="Findings by Severity", box=None)
        sev_table.add_column("Severity", style="bold")
        sev_table.add_column("Count", justify="right")

        for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]:
            count = len([f for f in result.findings if str(f.severity) == sev])
            if count:
                color = SEVERITY_COLORS.get(sev, "")
                sev_table.add_row(f"{color}{sev}", str(count))
        self.console.print(sev_table)
        self.console.print()

        # Detailed findings
        findings_table = Table(title="Findings Detail", show_lines=True)
        findings_table.add_column("Severity", width=10)
        findings_table.add_column("File", max_width=40)
        findings_table.add_column("Line", width=6, justify="right")
        findings_table.add_column("Algorithm", width=12)
        findings_table.add_column("Library", width=20)
        findings_table.add_column("Rule", width=20)

        for finding in sorted(result.findings, key=lambda f: (f.severity, str(f.file), f.line)):
            sev = str(finding.severity)
            color_tag = SEVERITY_COLORS.get(sev, "")
            findings_table.add_row(
                f"{color_tag}{sev}",
                str(finding.file),
                str(finding.line),
                str(finding.algorithm),
                finding.library,
                finding.rule_id,
            )
        self.console.print(findings_table)

    def print_remediation_result(self, result: RemediationResult) -> None:
        self.console.print()
        status = "[success]✅ Success[/success]" if result.success else "[critical]❌ Failed[/critical]"
        self.console.print(Panel(f"[header]🔧 Remediation Results[/header] — {status}", border_style="green"))

        table = Table(show_header=False, box=None, padding=(0, 2))
        table.add_column("Key", style="dim")
        table.add_column("Value", style="bold")
        table.add_row("Files modified", str(len(result.files_modified)))
        table.add_row("Findings remediated", str(len(result.findings_remediated)))
        table.add_row("Dry run", str(result.dry_run))
        table.add_row("Duration", f"{result.duration_seconds:.2f}s")
        if result.pr_url:
            table.add_row("Pull Request", f"[link={result.pr_url}]{result.pr_url}[/link]")
        self.console.print(table)

        if result.errors:
            self.console.print()
            self.console.print("[warning]⚠️  Errors:[/warning]")
            for err in result.errors:
                self.console.print(f"  [red]• {err}[/red]")

    def print_health(self, health: SystemHealth) -> None:
        icon = "✅" if health.is_healthy else "⚠️"
        self.console.print(Panel(f"[header]{icon} System Health[/header]", border_style="blue"))

        table = Table(show_header=False, box=None, padding=(0, 2))
        table.add_column("Key", style="dim")
        table.add_column("Value", style="bold")
        table.add_row("QuantumGuard Version", health.quantumguard_version)
        table.add_row("Python Version", health.python_version)
        table.add_row("Engines", ", ".join(health.registered_engines) or "none")
        table.add_row("Adapters", ", ".join(health.registered_adapters) or "none")
        table.add_row("Remediators", ", ".join(health.registered_remediators) or "none")
        self.console.print(table)

        self.console.print()
        dep_table = Table(title="Dependencies")
        dep_table.add_column("Package")
        dep_table.add_column("Status")
        for pkg, ok in health.dependencies.items():
            status = "[success]✅ installed[/success]" if ok else "[critical]❌ missing[/critical]"
            dep_table.add_row(pkg, status)
        self.console.print(dep_table)

        if health.issues:
            self.console.print()
            for issue in health.issues:
                self.console.print(f"[warning]⚠  {issue}[/warning]")

    def make_progress(self) -> Progress:
        return Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=self.console,
        )
