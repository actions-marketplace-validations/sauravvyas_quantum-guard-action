"""
Core Orchestrator — the central coordinator.

DESIGN CONTRACT:
  - No `if language == "python":` conditionals
  - No `if provider == "github":` conditionals
  - All dispatch goes through registries
  - This file must NEVER be modified to add new languages/adapters
"""
from __future__ import annotations

import logging
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from quantumguard.core.config import QuantumGuardConfig, get_config
from quantumguard.core.exceptions import (
    AdapterNotFoundError,
    EngineNotFoundError,
    RemediatorNotFoundError,
)
from quantumguard.core.models import (
    Finding,
    RemediationPlan,
    RemediationResult,
    ScanResult,
    ScanTarget,
    SupportedAdapter,
    SupportedLanguage,
)
from quantumguard.core.registry import (
    ADAPTER_REGISTRY,
    ENGINE_REGISTRY,
    REMEDIATOR_REGISTRY,
    get_adapter,
    get_engine,
    get_remediator,
)

logger = logging.getLogger(__name__)


class Orchestrator:
    """
    The central coordinator for all scan and remediation operations.

    Uses registries exclusively — no language or adapter conditionals.
    """

    def __init__(self, config: QuantumGuardConfig | None = None) -> None:
        self.config = config or get_config()
        self._ensure_output_dir()

    def _ensure_output_dir(self) -> None:
        self.config.output_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Scanning
    # ------------------------------------------------------------------

    def scan(
        self,
        target: ScanTarget,
        *,
        language_override: str | None = None,
    ) -> ScanResult:
        """
        Run a full scan on the given target.

        Dispatches to the appropriate engine via the ENGINE_REGISTRY.
        """
        logger.info("Starting scan: %s", target.path)
        
        # KILL SWITCH: Verify license before doing any work
        from quantumguard.core.licensing import verify_license
        is_valid, msg = verify_license()
        if not is_valid:
            logger.error("License verification failed: %s", msg)
            raise RuntimeError(f"License verification failed: {msg}")
            
        started_at = datetime.now(timezone.utc)
        t0 = time.perf_counter()

        # 1. Resolve adapter
        adapter_key = target.adapter.value if hasattr(target.adapter, "value") else str(target.adapter)
        adapter_cls = get_adapter(adapter_key)
        if adapter_cls is None:
            raise AdapterNotFoundError(adapter_key)
        adapter = adapter_cls(config=self.config)

        # 2. Discover files
        files = list(adapter.discover_files(target))
        logger.info("Discovered %d file(s) for scanning", len(files))

        # 3. Determine language(s) and dispatch to engines
        all_findings: list[Finding] = []
        errors: list[str] = []
        files_scanned = 0

        # Group files by language
        language_groups = self._group_files_by_language(files, language_override)

        for lang_key, lang_files in language_groups.items():
            engine_cls = get_engine(lang_key)
            if engine_cls is None:
                logger.warning("No engine for language '%s' — skipping %d file(s)", lang_key, len(lang_files))
                continue

            engine = engine_cls(config=self.config)
            logger.info("Scanning %d %s file(s)", len(lang_files), lang_key)

            for file_path in lang_files:
                try:
                    content = adapter.read_file(file_path)
                    findings = engine.scan(file_path, content)
                    all_findings.extend(findings)
                    files_scanned += 1
                except Exception as exc:
                    err_msg = f"Error scanning {file_path}: {exc}"
                    logger.error(err_msg)
                    errors.append(err_msg)

        elapsed = time.perf_counter() - t0
        files_with_findings = len({f.file for f in all_findings})

        result = ScanResult(
            target=target,
            findings=all_findings,
            files_scanned=files_scanned,
            files_with_findings=files_with_findings,
            errors=errors,
            duration_seconds=elapsed,
            started_at=started_at,
            completed_at=datetime.now(timezone.utc),
        )

        logger.info(
            "Scan complete: %d findings in %d files (%.2fs)",
            result.total_findings,
            files_with_findings,
            elapsed,
        )
        return result

    def _group_files_by_language(
        self,
        files: list[Path],
        language_override: str | None,
    ) -> dict[str, list[Path]]:
        """Group discovered files by their detected language."""
        from quantumguard.core.constants import LANGUAGE_EXTENSIONS

        if language_override:
            return {language_override.lower(): files}

        groups: dict[str, list[Path]] = {}
        ext_map: dict[str, str] = {}
        for lang, exts in LANGUAGE_EXTENSIONS.items():
            for ext in exts:
                ext_map[ext] = lang

        for fp in files:
            lang = ext_map.get(fp.suffix.lower())
            if lang and lang in ENGINE_REGISTRY:
                groups.setdefault(lang, []).append(fp)

        return groups

    # ------------------------------------------------------------------
    # Remediation
    # ------------------------------------------------------------------

    def remediate(
        self,
        plan: RemediationPlan,
        adapter_key: str = "filesystem",
    ) -> RemediationResult:
        """
        Execute a remediation plan.

        Dispatches to the appropriate remediator via REMEDIATOR_REGISTRY.
        """
        logger.info("Starting remediation for plan %s", plan.id)
        t0 = time.perf_counter()

        adapter_cls = get_adapter(adapter_key)
        if adapter_cls is None:
            raise AdapterNotFoundError(adapter_key)
        adapter = adapter_cls(config=self.config)

        # Group findings by language
        findings_by_language: dict[str, list[Finding]] = {}
        for finding in plan.findings:
            lang = str(finding.language)
            findings_by_language.setdefault(lang, []).append(finding)

        files_modified: list[Path] = []
        findings_remediated: list[str] = []
        errors: list[str] = []

        for lang_key, findings in findings_by_language.items():
            remediator_cls = get_remediator(lang_key)
            if remediator_cls is None:
                errors.append(f"No remediator for language '{lang_key}'")
                logger.warning("No remediator for language '%s'", lang_key)
                continue

            remediator = remediator_cls(config=self.config, adapter=adapter)
            try:
                modified, remediated = remediator.remediate(findings, dry_run=plan.dry_run)
                files_modified.extend(modified)
                findings_remediated.extend(remediated)
            except Exception as exc:
                err_msg = f"Remediation error for {lang_key}: {exc}"
                logger.error(err_msg)
                errors.append(err_msg)

        elapsed = time.perf_counter() - t0

        result = RemediationResult(
            plan_id=plan.id,
            files_modified=files_modified,
            findings_remediated=findings_remediated,
            errors=errors,
            duration_seconds=elapsed,
            dry_run=plan.dry_run,
            success=not errors,
        )

        logger.info(
            "Remediation complete: %d files modified, %d findings remediated (%.2fs)",
            len(files_modified),
            len(findings_remediated),
            elapsed,
        )
        return result

    # ------------------------------------------------------------------
    # Full pipeline: scan → remediate → PR
    # ------------------------------------------------------------------

    def full_pipeline(
        self,
        target: ScanTarget,
        *,
        adapter_key: str,
        repo: str | None = None,
        create_pr: bool = False,
        dry_run: bool = False,
    ) -> tuple[ScanResult, RemediationResult | None]:
        """
        Execute the complete scan → CBOM → remediate → PR pipeline.
        """
        scan_result = self.scan(target)

        if not scan_result.findings:
            logger.info("No findings — nothing to remediate")
            return scan_result, None

        plan = RemediationPlan(
            scan_result_id=scan_result.id,
            findings=scan_result.findings,
            dry_run=dry_run,
        )

        remediation_result = self.remediate(plan, adapter_key=adapter_key)

        if create_pr and not dry_run and repo:
            adapter_cls = get_adapter(adapter_key)
            if adapter_cls is not None:
                adapter = adapter_cls(config=self.config)
                if hasattr(adapter, "create_pull_request"):
                    try:
                        pr_url = adapter.create_pull_request(
                            repo=repo,
                            branch=plan.target_branch,
                            title=plan.pr_title,
                            body=plan.pr_body,
                        )
                        remediation_result.pr_url = pr_url
                        logger.info("PR created: %s", pr_url)
                    except Exception as exc:
                        logger.error("PR creation failed: %s", exc)
                        remediation_result.errors.append(f"PR creation failed: {exc}")

        return scan_result, remediation_result
