"""
Configuration management using Pydantic Settings.

Reads from environment variables and .env files.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from pydantic import Field, SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class QuantumGuardConfig(BaseSettings):
    """
    Centralised configuration.

    All sensitive values are SecretStr and never logged.
    """

    model_config = SettingsConfigDict(
        env_prefix="QUANTUMGUARD_",
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ---- General ----
    log_level: str = Field(default="INFO", description="Logging level")
    output_dir: Path = Field(default=Path(".quantumguard"), description="Output directory")
    max_workers: int = Field(default=4, ge=1, le=32, description="Parallel scan workers")

    # ---- Privacy ----
    privacy_mode: bool = Field(
        default=True,
        description="When True, source code never leaves the machine",
    )

    # ---- PQC Library ----
    pqc_index_url: str = Field(
        default="https://pypi.quantumguard.io/",
        description="PQC library index URL",
    )
    pqc_package_name: str = Field(default="quantumguard-pqc")
    pqc_protected_mode: bool = Field(
        default=False,
        description="Enable Cython-compiled protection for PQC lib",
    )

    # ---- GitHub ----
    github_token: SecretStr | None = Field(default=None)
    github_base_url: str = Field(default="https://api.github.com")

    # ---- GitLab ----
    gitlab_token: SecretStr | None = Field(default=None)
    gitlab_url: str = Field(default="https://gitlab.com")

    # ---- Bitbucket ----
    bitbucket_username: str | None = Field(default=None)
    bitbucket_app_password: SecretStr | None = Field(default=None)
    bitbucket_workspace: str | None = Field(default=None)

    # ---- Azure DevOps ----
    azure_pat: SecretStr | None = Field(default=None)
    azure_org_url: str | None = Field(default=None)

    # ---- API Server ----
    api_host: str = Field(default="127.0.0.1")
    api_port: int = Field(default=8080, ge=1024, le=65535)
    api_debug: bool = Field(default=False)

    # ---- CBOM ----
    cbom_include_metadata: bool = Field(default=True)

    @field_validator("log_level")
    @classmethod
    def validate_log_level(cls, v: str) -> str:
        allowed = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        upper = v.upper()
        if upper not in allowed:
            raise ValueError(f"log_level must be one of {allowed}")
        return upper

    @field_validator("output_dir", mode="before")
    @classmethod
    def coerce_path(cls, v: Any) -> Path:
        return Path(v)

    def ensure_output_dir(self) -> Path:
        self.output_dir.mkdir(parents=True, exist_ok=True)
        return self.output_dir


_config: QuantumGuardConfig | None = None


def get_config() -> QuantumGuardConfig:
    """Return the global config instance (singleton)."""
    global _config
    if _config is None:
        _config = QuantumGuardConfig()
    return _config


def reset_config() -> None:
    """Reset config — useful for testing."""
    global _config
    _config = None
