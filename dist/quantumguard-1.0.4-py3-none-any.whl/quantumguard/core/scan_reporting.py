"""
Optional CLI -> SaaS scan reporting.

After a local CLI scan/remediation completes, this posts a compact summary
(and, for repo-based scans, full findings) to the SaaS backend so it shows up
in scan history. Best-effort only: a network failure here must never affect
the CLI's own local output or exit code — source code and results always
stay usable locally regardless of whether the backend is reachable.

Privacy: finding metadata (file path, line, algorithm — never source code
content) is sent either way, same as `quantumguard scan --output report.json`
already writes locally today. `local_only` (default True for plain local
scans) only controls whether the backend keeps per-finding rows for a local
scan, or just the aggregate counts — repo-based scans (`remediate github`)
always keep full detail since the repo is already shared with the platform.
"""
from __future__ import annotations

import logging
import os

from quantumguard.core.licensing import TRIAL_KEY, get_license_key

logger = logging.getLogger("quantumguard.core.scan_reporting")


def _serialize_findings(findings) -> list[dict]:
    return [
        {
            "file": str(f.file),
            "line": f.line,
            "column": f.column,
            "end_line": f.end_line,
            "language": str(f.language),
            "algorithm": str(f.algorithm),
            "library": f.library,
            "rule_id": f.rule_id,
            "severity": str(f.severity),
            "recommendation": f.recommendation,
            "description": f.description,
            "cwe": f.cwe,
            "confidence": f.confidence,
            "remediated": f.remediated,
            "metadata": f.metadata,
        }
        for f in findings
    ]


def report_scan(
    scan_result,
    *,
    provider: str | None = None,
    repo: str | None = None,
    branch: str | None = None,
    pr_url: str | None = None,
    status: str = "completed",
    local_only: bool = True,
) -> None:
    """Best-effort POST of a scan result to the SaaS backend. Never raises."""
    key = get_license_key()
    if not key or key == TRIAL_KEY:
        return  # anonymous/offline usage — nothing to attribute this scan to

    saas_url = os.environ.get("QUANTUMGUARD_SAAS_URL", "http://localhost:8000").rstrip("/")
    payload = {
        "license": key,
        "source": "cli",
        "provider": provider,
        "repo": repo,
        "branch": branch,
        "target_path": str(scan_result.target.path),
        "status": status,
        "pr_url": pr_url,
        "local_only": local_only,
        "files_scanned": scan_result.files_scanned,
        "files_with_findings": scan_result.files_with_findings,
        "duration_seconds": scan_result.duration_seconds,
        "started_at": scan_result.started_at.isoformat(),
        "completed_at": scan_result.completed_at.isoformat() if scan_result.completed_at else None,
        "findings": _serialize_findings(scan_result.findings),
    }

    import httpx
    url = f"{saas_url}/api/v1/scans/ingest"

    # Free/low-tier hosting (e.g. Render) spins the backend down after a
    # period of inactivity — the first request to wake it can take well
    # over 5s. Try the fast path first (already-warm backend), then retry
    # once with a generous timeout to cover a cold start, instead of
    # giving up after a single short-timeout attempt.
    last_exc: Exception | None = None
    for timeout in (5.0, 30.0):
        try:
            response = httpx.post(url, json=payload, timeout=timeout)
            response.raise_for_status()
            logger.info("Reported scan to SaaS backend: %s", url)
            return
        except Exception as exc:  # noqa: BLE001 - best-effort, never break the CLI
            last_exc = exc
            logger.debug("Failed to report scan to SaaS backend (timeout=%.0fs): %s", timeout, exc)

    logger.warning(
        "Could not report scan to %s after retrying — it will not appear in your "
        "dashboard's scan history. Last error: %s", url, last_exc,
    )
