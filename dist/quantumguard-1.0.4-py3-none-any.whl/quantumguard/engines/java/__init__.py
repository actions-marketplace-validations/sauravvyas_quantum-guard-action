"""
Example Plugin: Java Language Engine (stub)

Shows how to add a new language engine WITHOUT modifying core files.

Installation:
  pip install quantumguard-java  (or place this file in quantumguard/engines/java/)

Registration (pyproject.toml of the plugin):
  [project.entry-points."quantumguard.engines"]
  java = "quantumguard_java.engine:JavaEngine"
"""
from __future__ import annotations

import logging
from pathlib import Path

from quantumguard.core.config import QuantumGuardConfig
from quantumguard.core.models import Finding, SupportedLanguage
from quantumguard.engines.base import LanguageEngine

logger = logging.getLogger(__name__)


class JavaEngine(LanguageEngine):
    """
    Java language engine — scans .java files for legacy cryptography.

    This is a STUB implementation. Install quantumguard-java for full support.
    """

    language = "java"
    EXTENSIONS = {".java"}

    def discover(self, root: Path) -> list[Path]:
        return [p for p in root.rglob("*.java") if p.is_file()]

    def scan(self, file_path: Path, content: str) -> list[Finding]:
        """
        Scan a Java file for cryptographic issues.

        Detects patterns like:
          import java.security.KeyPairGenerator;
          KeyPairGenerator.getInstance("RSA");
          new RSAKeyGenParameterSpec(1024, ...);
        """
        findings: list[Finding] = []
        lines = content.splitlines()
        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if 'getInstance("RSA")' in stripped or "getInstance('RSA')" in stripped:
                from quantumguard.core.models import Algorithm, Severity
                findings.append(
                    Finding(
                        file=file_path,
                        line=i,
                        column=0,
                        language=SupportedLanguage.JAVA,
                        algorithm=Algorithm.RSA,
                        library="java.security",
                        rule_id="PQC-JAVA-001",
                        severity=Severity.HIGH,
                        recommendation=(
                            "Replace RSA KeyPairGenerator with ML-KEM (FIPS 203) "
                            "or Hybrid PQC via BouncyCastle 1.78+ with SPHINCS+."
                        ),
                        description="RSA key generation via java.security.KeyPairGenerator",
                    )
                )
        return findings


def register() -> None:
    """Register the Java engine."""
    from quantumguard.core.registry import register_engine
    register_engine("java", JavaEngine)
    logger.info("Java engine registered")
