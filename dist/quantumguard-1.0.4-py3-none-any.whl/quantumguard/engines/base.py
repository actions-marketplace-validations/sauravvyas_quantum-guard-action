"""
Abstract base interfaces for language engines and remediators.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from quantumguard.core.config import QuantumGuardConfig
from quantumguard.core.models import Finding


class LanguageEngine(ABC):
    """
    Abstract language engine.

    Each language implements this interface. The orchestrator dispatches
    to engines via ENGINE_REGISTRY — never with language conditionals.
    """

    #: Language identifier — must match registry key
    language: str = ""

    def __init__(self, config: QuantumGuardConfig) -> None:
        self.config = config

    @abstractmethod
    def discover(self, root: Path) -> list[Path]:
        """Return all files this engine can process under root."""

    @abstractmethod
    def scan(self, file_path: Path, content: str) -> list[Finding]:
        """
        Scan a single file for cryptographic issues.

        PRIVACY: content is processed in-memory only. Never transmitted.
        Returns Finding objects (metadata only — no source code).
        """

    def remediate(self, file_path: Path, findings: list[Finding]) -> str:
        """
        Return rewritten file content with findings remediated.

        Default implementation raises NotImplementedError.
        Engines that support remediation must override this.
        """
        raise NotImplementedError(f"{self.__class__.__name__} does not support remediation")


class DetectionRule(ABC):
    """
    Abstract detection rule.

    Each rule targets a specific cryptographic pattern.
    Rules are composed by engines — never called directly by the orchestrator.
    """

    #: Unique rule identifier
    rule_id: str = ""

    #: Human-readable description
    description: str = ""

    def __init__(self, config: QuantumGuardConfig | None = None) -> None:
        self.config = config

    @abstractmethod
    def detect(self, file_path: Path, content: str, tree: Any) -> list[Finding]:
        """
        Run this rule against parsed content.

        Args:
            file_path: Path to the file being scanned.
            content: Raw source content (in-memory only).
            tree: Parsed AST or equivalent.

        Returns:
            List of findings (zero or more).
        """


class Remediator(ABC):
    """
    Abstract remediator.

    Each language implements its own remediation strategy.
    Registered in REMEDIATOR_REGISTRY and dispatched by the orchestrator.
    """

    #: Language this remediator handles
    language: str = ""

    def __init__(self, config: QuantumGuardConfig, adapter: Any | None = None) -> None:
        self.config = config
        self.adapter = adapter

    @abstractmethod
    def remediate(
        self,
        findings: list[Finding],
        *,
        dry_run: bool = False,
    ) -> tuple[list[Path], list[str]]:
        """
        Apply remediations for the given findings.

        Returns:
            Tuple of (modified_file_paths, remediated_finding_ids).
        """
