"""
Python Remediator — rewrites Python source files using libcst.

Uses libcst for safe, comment-preserving AST rewrites.
Never uses regex for code modification.
"""
from __future__ import annotations

import logging
from pathlib import Path
from collections import defaultdict
from typing import Sequence, Set, Union

import libcst as cst
import libcst.matchers as m

from quantumguard.core.config import QuantumGuardConfig
from quantumguard.core.constants import (
    PQC_RSA_PATCH,
    PQC_CRYPTO_PATCH,
    PQC_PYCRYPTO_PATCH,
    PQC_PACKAGE,
    PQC_PYPI_INDEX,
)
from quantumguard.core.exceptions import RewriteError, DependencyUpdateError
from quantumguard.core.models import Finding
from quantumguard.engines.base import Remediator

logger = logging.getLogger(__name__)

# Mapping from library → PQC replacement module
LIBRARY_REPLACEMENT_MAP = {
    "rsa": PQC_RSA_PATCH,
    "cryptography": PQC_CRYPTO_PATCH,
    "pycryptodome": PQC_PYCRYPTO_PATCH,
    "pycrypto": PQC_PYCRYPTO_PATCH,
}


class PythonImportRewriter(cst.CSTTransformer):
    """
    libcst transformer that replaces RSA import statements with PQC equivalents.

    PRIVACY: Only operates on in-memory CST. No source code is stored or transmitted.
    """

    def __init__(self, findings: list[Finding]) -> None:
        self.findings = findings
        # Build set of (line, library) pairs to rewrite
        self._target_lines: Set[int] = {f.line for f in findings}
        self._changed = False

    def leave_Import(
        self, original_node: cst.Import, updated_node: cst.Import
    ) -> Union[cst.Import, cst.RemovalSentinel]:
        new_names = []
        for alias in original_node.names:
            module_str = _module_name(alias.name)
            if module_str == "rsa":
                self._changed = True
                # Replace `import rsa` with `import quantumguard_pqc.rsa_patch as rsa`
                new_alias = cst.ImportAlias(
                    name=_str_to_attribute("quantumguard_pqc.rsa_patch"),
                    asname=cst.AsName(name=cst.Name("rsa"))
                )
                new_names.append(new_alias)
            elif "cryptography.hazmat" in module_str or "Crypto.PublicKey" in module_str:
                self._changed = True
                new_alias = cst.ImportAlias(
                    name=_str_to_attribute("quantumguard_pqc.crypto_patch"),
                    asname=cst.AsName(name=cst.Name(module_str.split(".")[0]))
                )
                new_names.append(new_alias)
            else:
                new_names.append(alias)
                
        if self._changed:
            return updated_node.with_changes(names=new_names)
        return updated_node

    def leave_ImportFrom(
        self,
        original_node: cst.ImportFrom,
        updated_node: cst.ImportFrom,
    ) -> cst.ImportFrom:
        if not original_node.module:
            return updated_node

        module_str = _module_name(original_node.module)

        # rsa.*
        if module_str == "rsa" or module_str.startswith("rsa."):
            self._changed = True
            new_module = cst.Attribute(
                value=cst.Name("quantumguard_pqc"),
                attr=cst.Name("rsa_patch"),
            )
            return updated_node.with_changes(module=new_module)

        # cryptography.hazmat.primitives.asymmetric.*
        if "cryptography.hazmat.primitives.asymmetric" in module_str:
            self._changed = True
            new_module = _str_to_attribute("quantumguard_pqc.cryptography_patch")
            return updated_node.with_changes(module=new_module)

        # Crypto.PublicKey.* / Cryptodome.PublicKey.*
        if "Crypto.PublicKey" in module_str or "Cryptodome.PublicKey" in module_str:
            self._changed = True
            new_module = _str_to_attribute("quantumguard_pqc.pycryptodome_patch")
            return updated_node.with_changes(module=new_module)

        return updated_node

    def leave_SimpleStatementLine(
        self,
        original_node: cst.SimpleStatementLine,
        updated_node: cst.SimpleStatementLine,
    ) -> cst.SimpleStatementLine:
        """Add a comment marker to rewritten import lines."""
        for stmt in updated_node.body:
            if isinstance(stmt, cst.Import) and self._changed:
                return updated_node.with_changes(
                    trailing_whitespace=cst.TrailingWhitespace(
                        whitespace=cst.SimpleWhitespace("  "),
                        comment=cst.Comment("# [QuantumGuard] Migrated to Hybrid PQC"),
                    )
                )
        return updated_node


def _module_name(node: cst.BaseExpression) -> str:
    """Reconstruct dotted module name from CST node."""
    if isinstance(node, cst.Name):
        return node.value
    if isinstance(node, cst.Attribute):
        return f"{_module_name(node.value)}.{node.attr.value}"
    return ""


def _str_to_attribute(dotted: str) -> cst.BaseExpression:
    """Convert 'a.b.c' string to CST Attribute chain."""
    parts = dotted.split(".")
    node: cst.BaseExpression = cst.Name(parts[0])
    for part in parts[1:]:
        node = cst.Attribute(value=node, attr=cst.Name(part))
    return node


class PythonRemediator(Remediator):
    """
    Remediates Python files with RSA → Hybrid PQC migrations.

    Steps:
      1. Rewrite imports using libcst
      2. Update requirements.txt / pyproject.toml
    """

    language = "python"

    def remediate(
        self,
        findings: list[Finding],
        *,
        dry_run: bool = False,
    ) -> tuple[list[Path], list[str]]:
        """Apply remediations. Returns (modified_files, remediated_finding_ids)."""
        # Group findings by file
        findings_by_file: dict[Path, list[Finding]] = defaultdict(list)
        for finding in findings:
            findings_by_file[finding.file].append(finding)

        modified_files: list[Path] = []
        remediated_ids: list[str] = []

        for file_path, file_findings in findings_by_file.items():
            try:
                modified = self._rewrite_file(file_path, file_findings, dry_run=dry_run)
                if modified:
                    modified_files.append(file_path)
                    remediated_ids.extend(f.id for f in file_findings)
            except Exception as exc:
                logger.error("Failed to rewrite %s: %s", file_path, exc)

        # Update dependency files
        if modified_files:
            try:
                dep_files = self._update_dependencies(
                    root=modified_files[0].parent,
                    dry_run=dry_run,
                )
                modified_files.extend(dep_files)
            except Exception as exc:
                logger.warning("Failed to update dependencies: %s", exc)

        return modified_files, remediated_ids

    def _rewrite_file(
        self,
        file_path: Path,
        findings: list[Finding],
        *,
        dry_run: bool,
    ) -> bool:
        """Rewrite a single file using libcst. Returns True if changes were made."""
        if not file_path.exists():
            logger.warning("File not found: %s", file_path)
            return False

        content = file_path.read_text(encoding="utf-8")

        try:
            source_tree = cst.parse_module(content)
        except cst.ParserSyntaxError as exc:
            raise RewriteError(f"Failed to parse {file_path}: {exc}") from exc

        transformer = PythonImportRewriter(findings)
        modified_tree = source_tree.visit(transformer)

        if not transformer._changed:
            logger.debug("No changes needed in %s", file_path)
            return False

        new_content = modified_tree.code
        if not dry_run:
            file_path.write_text(new_content, encoding="utf-8")
            logger.info("Rewrote: %s", file_path)
        else:
            logger.info("[DRY RUN] Would rewrite: %s", file_path)

        return True

    def _update_dependencies(self, root: Path, *, dry_run: bool) -> list[Path]:
        """Update dependency files to include quantumguard-pqc."""
        modified: list[Path] = []

        # Walk up to find project root
        search_root = root
        for _ in range(5):
            req_txt = search_root / "requirements.txt"
            if req_txt.exists():
                if self._update_requirements_txt(req_txt, dry_run=dry_run):
                    modified.append(req_txt)

            pyproject = search_root / "pyproject.toml"
            if pyproject.exists():
                if self._update_pyproject_toml(pyproject, dry_run=dry_run):
                    modified.append(pyproject)

            if search_root.parent == search_root or (search_root / ".git").exists():
                break
            search_root = search_root.parent

        return modified

    def _update_requirements_txt(self, req_file: Path, *, dry_run: bool) -> bool:
        """Add quantumguard-pqc to requirements.txt if not already present."""
        content = req_file.read_text(encoding="utf-8")
        if PQC_PACKAGE in content:
            return False

        addition = (
            f"\n# [QuantumGuard] Post-Quantum Cryptography shim library\n"
            f"--extra-index-url {PQC_PYPI_INDEX}\n"
            f"{PQC_PACKAGE}\n"
        )
        new_content = content + addition

        if not dry_run:
            req_file.write_text(new_content, encoding="utf-8")
            logger.info("Updated: %s", req_file)
        else:
            logger.info("[DRY RUN] Would update: %s", req_file)

        return True

    def _update_pyproject_toml(self, pyproject: Path, *, dry_run: bool) -> bool:
        """Add quantumguard-pqc to pyproject.toml dependencies."""
        import toml

        try:
            data = toml.loads(pyproject.read_text(encoding="utf-8"))
        except Exception as exc:
            logger.warning("Could not parse pyproject.toml: %s", exc)
            return False

        deps = data.get("project", {}).get("dependencies", [])
        if any(PQC_PACKAGE in str(d) for d in deps):
            return False

        deps.append(f"{PQC_PACKAGE}>=1.0.0")
        data.setdefault("project", {})["dependencies"] = deps

        new_content = toml.dumps(data)
        if not dry_run:
            pyproject.write_text(new_content, encoding="utf-8")
            logger.info("Updated: %s", pyproject)
        else:
            logger.info("[DRY RUN] Would update: %s", pyproject)

        return True
