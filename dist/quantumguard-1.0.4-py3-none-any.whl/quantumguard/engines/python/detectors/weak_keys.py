"""
Detection Rule: Weak RSA key sizes

Detects RSA key generation calls with insufficient key sizes.

Patterns detected:
  RSA.generate(1024)
  rsa.newkeys(512)
  generate_private_key(public_exponent=65537, key_size=1024, ...)
"""
from __future__ import annotations

import ast
from pathlib import Path
from typing import Any

from quantumguard.core.constants import (
    CWE_WEAK_KEY_SIZE,
    WEAK_RSA_KEY_BITS,
    RSA_SEVERITY_THRESHOLDS,
)
from quantumguard.core.models import Algorithm, Finding, Severity, SupportedLanguage
from quantumguard.engines.base import DetectionRule

_RSA_GENERATE_CALLS = {
    "generate",         # RSA.generate(1024)
    "newkeys",          # rsa.newkeys(512)
    "generate_private_key",  # cryptography API
}


def _get_severity_for_key_size(key_size: int) -> Severity:
    """
    Map key size to severity using ascending threshold list.
    e.g. 512 <= 1024 → CRITICAL, 2048 <= 2048 → HIGH
    """
    for threshold, sev in RSA_SEVERITY_THRESHOLDS:
        if key_size <= threshold:
            return Severity(sev)
    return Severity.LOW


class WeakKeyDetector(DetectionRule):
    """Detects RSA key generation with weak key sizes (< 2048 bits)."""

    rule_id = "PQC-PY-004"
    description = "Weak RSA key size detected"

    def detect(self, file_path: Path, content: str, tree: Any) -> list[Finding]:
        findings: list[Finding] = []

        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue

            func_name = self._get_func_name(node)
            if func_name not in _RSA_GENERATE_CALLS:
                continue

            key_size = self._extract_key_size(node, func_name)
            if key_size is None:
                continue

            if key_size >= WEAK_RSA_KEY_BITS:
                # Key is adequate size but still quantum-vulnerable
                severity = Severity.MEDIUM
                description = (
                    f"RSA key size {key_size} bits is adequate for classical "
                    "security but vulnerable to quantum attacks (Shor's algorithm)."
                )
            else:
                severity = _get_severity_for_key_size(key_size)
                description = (
                    f"RSA key size {key_size} bits is below the recommended "
                    f"minimum of {WEAK_RSA_KEY_BITS} bits."
                )

            findings.append(
                Finding(
                    file=file_path,
                    line=node.lineno,
                    column=node.col_offset,
                    end_line=getattr(node, "end_lineno", None),
                    language=SupportedLanguage.PYTHON,
                    algorithm=Algorithm.WEAK_KEY,
                    library="detected",
                    rule_id=self.rule_id,
                    severity=severity,
                    recommendation=(
                        "Use Hybrid PQC key exchange (ML-KEM-768 + RSA-3072) via "
                        "`quantumguard_pqc`. RSA alone is quantum-vulnerable regardless of key size."
                    ),
                    description=description,
                    cwe=[CWE_WEAK_KEY_SIZE],
                    metadata={"key_size": key_size, "function": func_name},
                )
            )

        return findings

    @staticmethod
    def _get_func_name(call_node: ast.Call) -> str:
        """Extract the function/method name from a call node."""
        if isinstance(call_node.func, ast.Name):
            return call_node.func.id
        if isinstance(call_node.func, ast.Attribute):
            return call_node.func.attr
        return ""

    @staticmethod
    def _extract_key_size(call_node: ast.Call, func_name: str) -> int | None:
        """Extract the key size integer from a call node."""
        # RSA.generate(bits) / rsa.newkeys(nbits) — first positional arg
        if func_name in ("generate", "newkeys"):
            if call_node.args:
                arg = call_node.args[0]
                if isinstance(arg, ast.Constant) and isinstance(arg.value, int):
                    return arg.value

        # generate_private_key(public_exponent=65537, key_size=2048, backend=...)
        if func_name == "generate_private_key":
            for kw in call_node.keywords:
                if kw.arg == "key_size":
                    if isinstance(kw.value, ast.Constant) and isinstance(kw.value.value, int):
                        return kw.value.value
            # Also check second positional argument
            if len(call_node.args) >= 2:
                arg = call_node.args[1]
                if isinstance(arg, ast.Constant) and isinstance(arg.value, int):
                    return arg.value

        return None
