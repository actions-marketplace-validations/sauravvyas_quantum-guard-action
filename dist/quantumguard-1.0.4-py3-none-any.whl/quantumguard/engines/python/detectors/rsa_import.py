"""
Detection Rule: import rsa

Detects direct imports of the `rsa` package.

Patterns detected:
  import rsa
  import rsa as something
"""
from __future__ import annotations

import ast
from pathlib import Path
from typing import Any

from quantumguard.core.constants import (
    CWE_QUANTUM_VULNERABLE,
    CWE_WEAK_CRYPTOGRAPHY,
)
from quantumguard.core.models import Algorithm, Finding, Severity, SupportedLanguage
from quantumguard.engines.base import DetectionRule


class RSAImportDetector(DetectionRule):
    """Detects usage of the top-level `rsa` package."""

    rule_id = "PQC-PY-001"
    description = "Direct import of the `rsa` package detected"

    def detect(self, file_path: Path, content: str, tree: Any) -> list[Finding]:
        findings: list[Finding] = []

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name == "rsa" or alias.name.startswith("rsa."):
                        findings.append(
                            Finding(
                                file=file_path,
                                line=node.lineno,
                                column=node.col_offset,
                                end_line=node.end_lineno,
                                language=SupportedLanguage.PYTHON,
                                algorithm=Algorithm.RSA,
                                library="rsa",
                                rule_id=self.rule_id,
                                severity=Severity.HIGH,
                                recommendation=(
                                    "Replace `import rsa` with "
                                    "`from quantumguard_pqc import rsa_patch as rsa` "
                                    "to use the Hybrid PQC (ML-KEM-768 + RSA-3072) shim."
                                ),
                                description=self.description,
                                cwe=[CWE_QUANTUM_VULNERABLE, CWE_WEAK_CRYPTOGRAPHY],
                                metadata={"import_name": alias.name, "alias": alias.asname},
                            )
                        )

            elif isinstance(node, ast.ImportFrom):
                if node.module and (node.module == "rsa" or node.module.startswith("rsa.")):
                    findings.append(
                        Finding(
                            file=file_path,
                            line=node.lineno,
                            column=node.col_offset,
                            end_line=node.end_lineno,
                            language=SupportedLanguage.PYTHON,
                            algorithm=Algorithm.RSA,
                            library="rsa",
                            rule_id=self.rule_id,
                            severity=Severity.HIGH,
                            recommendation=(
                                "Replace `from rsa import ...` with the "
                                "`quantumguard_pqc` Hybrid PQC equivalent."
                            ),
                            description=self.description,
                            cwe=[CWE_QUANTUM_VULNERABLE, CWE_WEAK_CRYPTOGRAPHY],
                            metadata={
                                "module": node.module,
                                "names": [a.name for a in node.names],
                            },
                        )
                    )

        return findings
